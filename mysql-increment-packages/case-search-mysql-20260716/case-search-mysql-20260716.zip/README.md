# 病例查询 MySQL 增量包

## 修改内容

1. 新增 `app/Services/MysqlCaseSearchService.php`
   - 将全病例普通搜索 `normalSearch` 从 ES 查询改为 MySQL 查询。
   - 将全病例高级搜索 `searchData` 从 ES 查询改为 MySQL 查询。
   - 保持前端返回结构：`data.list`、`data.detail.EMR_BL_BL01`、`data.detail.FeeDetailed`、`data.detail.YZB`、`total`、`total_page`。

2. 修改 `app/Http/Controllers/Api/QualityController.php`
   - 引入 `MysqlCaseSearchService`。
   - `normalSearch()` 开头切换到 MySQL 服务。
   - `searchData()` 开头切换到 MySQL 服务。
   - 原 ES 代码未删除，保留在 return 后面，方便回滚参考。

## 涉及接口

- `POST /api/normalSearch`：全病例普通搜索
- `POST /api/search`：全病例高级搜索

## 主要 MySQL 表

- `patient_info`
- `EMR_BL_BL01`
- `EMR_BL_BLXG`
- `fee_detailed`
- `yzb`
- `main_operation`
- `secondary_operation`
- `other_diagnosis`

## 测试服务器验证

测试服务器路径：`/data/quality/homeQuality`
备份目录：`/data/quality/backup_case_search_mysql_20260716183733`

已完成：

- `php -l /data/api/app/Services/MysqlCaseSearchService.php`：通过
- `php -l /data/api/app/Http/Controllers/Api/QualityController.php`：通过
- `POST /api/normalSearch` 空条件：返回 200
- `POST /api/search` 空条件：返回 200
- `POST /api/normalSearch` 关键词 `转科`：返回 200，有 YZB 明细和高亮
- `POST /api/search` field 医嘱 `转科`：返回 200，有 YZB 明细和高亮