<?php

namespace App\Console\Commands\BigModel;

use App\Model\BigModelQualityResult;
use App\Model\BigModelTemplate;
use App\Model\CaseQuality;
use App\Model\EMR_BL_BL01;
use App\Model\EMR_BL_BLXG;
use App\Model\PatientInfo;
use Illuminate\Console\Command;

class Index extends Command
{
    public const APIURL = 'http://172.16.9.43:7997/api/predict/';
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'big_model {start?}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = '大模型-入院记录质控';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $star = $this->argument('start');
        $star = $star ?? date("Y-m-1", time() - 10 * 24 * 3600);
        // 读取大模型设置的质控模板
        $temp = BigModelTemplate::query()->get()->toArray();

        // 根据模板设置的数据源和规则进行质控
        foreach ($temp as $t) {
            $methods = json_decode($t['data_type'], true);
            foreach ($methods as $method) {
                if (method_exists($this, $method)) {
                    $this->$method($star, $t);
                }
            }
        }
    }

    /**
     * 入院记录质控
     */
    public function RYJL($star = "", $t = [])
    {
        $bl01 = EMR_BL_BL01::query()->selectRaw("min(BLBH) as BLBH")->where('BLLB', '=', 292)->where("ZXSJ", ">", $star)->limit(1)->get()->toArray();
        $id = $bl01[0]['BLBH'] ?? 0;
        while (true) {
            $bl01 = EMR_BL_BL01::query()->select(['BLBH', 'JZHM', 'BRBH'])->where('BLLB', '=', 292)->where("BLBH", ">", $id)->limit(1000)->get()->toArray();
            if (empty($bl01)) {
                break;
            }
            $blbh = array_column($bl01, 'BLBH');
            $id = max($blbh);
            $blxg = EMR_BL_BLXG::query()->whereIn('BLBH', $blbh)->get()->toArray();
            $blxg = array_column($blxg, null, 'BLBH');

            foreach ($bl01 as $item) {
                $startTime = time();
                $content = $blxg[$item['BLBH']]['HJNR'] ?? '';
                if (empty($content)) {
                    continue;
                }
                $content = str_replace(' ', '', $content);
                $content = str_replace("\r\n", "", $content);
                $content = str_replace("\n", "", $content);
                $content = str_replace('{params}', $content, $t['content']);
                var_dump($content);
                $res = requestPost(self::APIURL, ['query' => $content]);


                $response = $res->result->response ?? "";
                var_dump($response);
                if (strpos($response, '"错误"') === false) {
                    var_dump('结果无错误，无需保存：' . date("Y-m-d H:i:s") . "\r\n");
                    continue;
                }
                $res = str_replace(["`", "json"], ' ', $response);
                $res = json_decode($res, 'true');
                $errorNotice = [
                    'basis' => json_encode($res, 256),
                    'JZHM' => $item['JZHM'],
                    'rule_id' => $t['rule_id'],
                    'code' => '',
                    'error_field' => ''
                ];
                CaseQuality::addData($errorNotice);
                PatientInfo::query()->where('MED_REC_ID', '=', $item['JZHM'])->update(['is_defect' => 1]);
                echo '用时：' . (time() - $startTime) . "秒\r\n";
                var_dump($res);
            }
        }

    }

    /**
     * 出院记录质控
     */
    public function CYJL($star = "", $t = [])
    {
        $bl01 = EMR_BL_BL01::query()->selectRaw("min(BLBH) as BLBH")->where('BLLB', '=', 1)->where("ZXSJ", ">", $star)->limit(1)->get()->toArray();
        $id = $bl01[0]['BLBH'] ?? 0;
        while (true) {
            $bl01 = EMR_BL_BL01::query()->select(['BLBH', 'JZHM', 'BRBH'])->where('BLLB', '=', 1)->where("BLBH", ">", $id)->limit(1000)->get()->toArray();
            if (empty($bl01)) {
                break;
            }
            $blbh = array_column($bl01, 'BLBH');
            $id = max($blbh);
            $blxg = EMR_BL_BLXG::query()->whereIn('BLBH', $blbh)->get()->toArray();
            $blxg = array_column($blxg, null, 'BLBH');

            foreach ($bl01 as $item) {
                $startTime = time();
                $content = $blxg[$item['BLBH']]['HJNR'] ?? '';
                if (empty($content)) {
                    continue;
                }
                $content = str_replace(' ', '', $content);
                $content = str_replace("\r\n", "", $content);
                $content = str_replace("\n", "", $content);
                $content = str_replace('{params}', $content, $t['content']);
                var_dump($content);
                $res = requestPost(self::APIURL, ['query' => $content]);


                $response = $res->result->response ?? "";
                var_dump($response);
                if (strpos($response, '"错误"') === false) {
                    var_dump('结果无错误，无需保存：' . date("Y-m-d H:i:s") . "\r\n");
                    continue;
                }
                $res = str_replace(["`", "json"], ' ', $response);
                $res = json_decode($res, 'true');
                $errorNotice = [
                    'basis' => json_encode($res, 256),
                    'JZHM' => $item['JZHM'],
                    'rule_id' => $t['rule_id'],
                    'code' => '',
                    'error_field' => ''
                ];
                CaseQuality::addData($errorNotice);
                PatientInfo::query()->where('MED_REC_ID', '=', $item['JZHM'])->update(['is_defect' => 1]);
                echo '用时：' . (time() - $startTime) . "秒\r\n";
                var_dump($res);
            }
        }

    }


}
