<?php

namespace App\Exports;

use Generator;
use Maatwebsite\Excel\Concerns\FromGenerator;
use Maatwebsite\Excel\Concerns\WithHeadings;

class DefectIssuesAllExport implements FromGenerator, WithHeadings
{
    /**
     * @var array
     */
    private $title;

    /**
     * @var \Closure
     */
    private $rowGenerator;

    /**
     * @param array    $title
     * @param \Closure $rowGenerator 返回 Generator 的闭包
     */
    public function __construct(array $title, \Closure $rowGenerator)
    {
        $this->title = $title;
        $this->rowGenerator = $rowGenerator;
    }

    public function headings(): array
    {
        return $this->title;
    }

    public function generator(): Generator
    {
        $generator = ($this->rowGenerator)();

        foreach ($generator as $row) {
            yield $row;
        }
    }
}

