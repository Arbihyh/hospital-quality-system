<?php
/**
 * 科室质控详页面情
 */

namespace App\Http\Controllers\Api\Artificial\Department;

use App\Http\Controllers\Controller;
use App\Model\CaseQuality;
use App\Model\CaseQualityDoctor;
use App\Model\CaseQualityZm;
use App\Model\CaseRule;
use App\Model\Department;
use App\Model\ErrorRule;
use App\Model\ErrorV2;
use App\Model\HomeQuality;
use App\Model\PatientDoctorInfo;
use App\Model\PatientInfo;
use App\Model\QualitySendMsgLog;
use App\Model\Staff;
use App\Services\CaseService;
use App\Services\ToolsService;
use Illuminate\Http\Request;
use mysql_xdevapi\Exception;


class DetailController extends Controller
{
    public function __construct()
    {
        parent::__construct();

    }

    public function getZkInfo()
    {
        $sy_zk = ErrorRule::query()->where('is_artificial', 2)->get(['id as value', 'desc as label', 'down', 'error_type',
            'level', 'type'])
            ->toArray();
        $bl_zk = CaseRule::query()->where('is_ai', 2)->get(['id as value', 'notice as label', 'score', 'level', 'category'])
            ->toArray();
        $data = [];
        $data[0]['label'] = '首页质控规则';
        $data[0]['value'] = '1';
        $data[0]['children'] = $sy_zk;
        $data[1]['label'] = "病历质控规则";
        $data[1]['value'] = "2";
        $data[1]['children'] = $bl_zk;
        return ToolsService::returnData(200, $data);
    }


    public function addRule(Request $request)
    {
        //region 判断数据===

        $data = [];
        $zk_type = $request->post('zk_type');
        if ($zk_type != 1 && $zk_type != 2) return ToolsService::returnData(1, [], '请选择正确的质控规则类型');
        $currentTime = date("Y-m-d H:i:s");

        //region 如果是首页质控
        if ($zk_type == 1) {
            //质控规则名称
            $data['field'] = $request->post('field', '');
            if (empty($data['field'])) return ToolsService::returnData(1, [], '质控规则名称不能为空');
            if (!empty(ErrorRule::query()->where('field', $data['field'])->first())) return ToolsService::returnData(1, [], '此条质控规则已经存在');
            //错误扣分
            $data['down'] = $request->post('down', '');
            if (empty($data['down'])) return ToolsService::returnData(1, [], '请填写正确的错误扣分');
            //错误级别
            $data['level'] = $request->post('level', '');
            if (!is_numeric($data['level'])) return ToolsService::returnData(1, [], '请选择正确的错误级别');
            //缺陷分类
            $data['type'] = $request->post('type', '');
            if (!is_numeric($data['type'])) return ToolsService::returnData(1, [], '请选择正确的缺陷分类');
            //缺陷类型
            $data['error_type'] = $request->post('error_type', '');
            if (!is_numeric($data['error_type'])) return ToolsService::returnData(1, [], '请选择正确的错误类型');
            //缺陷类别
            $data['category'] = $request->post('category');
            if (!is_numeric($data['category'])) return ToolsService::returnData(1, [], '请选择正确的缺陷类别');
            //质控描述
            $data['desc'] = $request->post('desc', '');
            if (!$data['desc']) return ToolsService::returnData(1, [], '请填写质控描述');

            $data['auth'] = 'is_artificial';
            $data['created_at'] = $currentTime;
            $data['updated_at'] = $currentTime;
            $data['is_artificial'] = 2;
            if (!ErrorRule::query()->insert($data)) return ToolsService::returnData(1, [], '添加质控规则失败');
        }
        //endregion

        //region 如果是病历质控===
        if ($zk_type == 2) {
            //质控名称
            $data['title'] = $request->post('field', '');
            if (empty($data['title'])) return ToolsService::returnData(1, [], '请填写正确的质控名称');
            if (!empty(CaseRule::query()->where('title', $data['title'])->first())) return ToolsService::returnData(1, [], '此条质控规则已经存在');
            //错误扣分
            $data['score'] = $request->post('down', '');
            if ($data['score'] < 0.5 || $data['score'] > 100) return ToolsService::returnData(1, [], '错误扣分不在0.5-100之间');
            //错误级别
            $data['level'] = $request->post('level');
            if (!is_numeric($data['level'])) return ToolsService::returnData(1, [], '请选择错误级别');

            //错误描述
            $data['notice'] = $request->post('desc', "") or "";
            if (!$data['notice']) return ToolsService::returnData(1, [], '请填写质控描述');

            $data['category'] = "人工质控";
            $data['is_ai'] = 2;
            $data['created_at'] = $currentTime;
            $data['updated_at'] = $currentTime;
            if (!CaseRule::query()->insert($data)) return ToolsService::returnData(1, [], '添加病历质控规则失败');

        }
        //endregion

        return ToolsService::returnData(200, [], '添加质控规则成功');
    }

    /**
     * @param Request $request
     * @return array
     */
    public function addQualityControlInfo(Request $request)
    {
        //region 判断数据===
        $data = [];
        //住院号
        $MED_REC_ID = $request->post('MED_REC_ID');
        if (empty($MED_REC_ID)) return ToolsService::returnData(1, [], '住院号不能为空');
        $patientRow = PatientInfo::query()->where('MED_REC_ID', $MED_REC_ID)->first();
        if (empty($patientRow)) return ToolsService::returnData(1, [], '此住院号不存在');

        //质控规则
        $ruleArray = $request->post('ruleArray');
        if (empty($ruleArray)) return ToolsService::returnData(1, [], '请选择正确的质控规则');
        $rule_type = $ruleArray[0];

        if ($rule_type != 1 && $rule_type != 2) return ToolsService::returnData(1, [], '请选择正确的质控规则');


        $rule_id = $ruleArray[1];
        if (!is_numeric($rule_id)) return ToolsService::returnData(1, [], '请选择正确的质控规则');

        //如果是首页质控规则
        if ($rule_type == 1) {
            $ruleRow = ErrorRule::query()->where('is_artificial', 2)->where('id', $rule_id)->first();
            if (empty($ruleRow)) return ToolsService::returnData(1, [], '此质控规则不存在');
        }

        //如果是病历质控规则
        if ($rule_type == 2) {
            $ruleRow = CaseRule::query()->where('is_ai', 2)->where('id', $rule_id)->first();
            if (empty($ruleRow)) return ToolsService::returnData(1, [], '此质控规则不存在');
        }

        //接收端
        $data['cate'] = $request->post('cate');
        if (empty($data['cate'])) return ToolsService::returnData(1, [], '请选择正确的接收端');

        //接收科室
        $data['JSKS'] = $request->post('JSKS');
        if (empty($data['JSKS'])) return ToolsService::returnData(1, [], '请选择正确的接收科室');

        //接收人
        $data['JSR'] = $request->post('JSR');
        if (empty($data['JSR'])) return ToolsService::returnData(1, [], '请选择正确的接收人');

        //整改天数
        $data['correction_date'] = $request->post('correction_date', 7);

        //整改依据
        $data['basis'] = $request->post('basis');
        if (empty($data['basis'])) return ToolsService::returnData(1, [], '请填写质控依据');
        $basis = $data['basis'];

        //整改说明
        $data['notice'] = $request->post('notice');
        if (empty($data['notice'])) return ToolsService::returnData(1, [], '请填写质控内容');

        // 质控人
        $data['ZKR'] = $request->post('ZKR');
        if (empty($data['ZKR'])) return ToolsService::returnData(1, [], '请填写质控人');

        // 质控目录
        $data['error_field'] = $request->post('error_field');
        if (empty($data['error_field'])) return ToolsService::returnData(1, [], '请选择质控目录');
        //endregion

        $currentTime = date("Y-m-d H:i:s");//当前时间
        // 编目首页
        $patientDoctorRow = PatientDoctorInfo::query()->where('AAA28', $patientRow['MED_REC_ID'])->first();
        if ($data['cate'] == 3) {
            //插入数据
            $data['basis'] = json_encode([$data['basis']], 256);
            $data['AAA28'] = $patientRow['AAA28'];
            $data['ZYH'] = $patientRow['MED_REC_ID'];
            $data['AAC01'] = $patientRow['AAC01'];
            $data['AAC02C'] = $patientRow['AAC02C'];
            $data['YQ_CODE'] = $patientRow['YQ_CODE'];
            $data['AAC11C'] = $patientRow['BQ_CODE'];
            $data['in_hospital'] = $patientRow['in_hospital'];
            $data['is_CATA'] = $patientRow['IS_CATA'];
            $data['AEE01_CODE'] = $patientDoctorRow['AEE01_CODE'] ?? "";
            $data['AEE02_CODE'] = $patientDoctorRow['AEE02_CODE'] ?? "";
            $data['AEE03_CODE'] = $patientDoctorRow['AEE03_CODE'] ?? "";
            $data['AEE04_CODE'] = $patientDoctorRow['AEE04_CODE'] ?? "";
            $data['error_rule'] = $ruleRow['id'];
            $data['is_artificial'] = 1;
            $data['created_at'] = $currentTime;
            $data['updated_at'] = $currentTime;
            $data['submit_user'] = $request->user()['id'];
            $lastId = HomeQuality::query()->insertGetId($data);

            $title = "编目首页整改通知提醒";
        } // 运行首页
        elseif ($data['cate'] == 2) {

            $department = Department::query()->get()->toArray();
            $department = array_column($department, 'dep_name', 'dep_id');

            $staff = Staff::query()->get()->toArray();
            $staff = array_column($staff, 'name', 'code');
            //插入数据
            $data['AAA01'] = $patientRow['AAA01'];
            $data['AAA28'] = $patientRow['AAA28'];
            $data['ZYH'] = $patientRow['MED_REC_ID'];
            $data['AAB01'] = $patientRow['AAB01'];
            $data['AAC01'] = $patientRow['AAC01'];
            $data['error_rule'] = $ruleRow['id'];
            $data['desc'] = $ruleRow['desc'];
            $data['coder_id'] = $patientRow['AEE08_CODE'];
            $data['CYKSBM'] = $patientRow['AAC02C'];
            $data['coder_name'] = $staff[$patientRow['AEE08_CODE']] ?? "";
            $data['coder_name'] = $department[$patientRow['AAC02C']] ?? "";
            $data['ZZYS_BH'] = $patientDoctorRow['AEE03_CODE'] ?? "";
            $data['ZZYS_BH'] = $patientDoctorRow['AEE03'] ?? "";
            $data['ZYYS_BH'] = $patientDoctorRow['AEE04'] ?? "";
            $data['ZYYS'] = $patientDoctorRow['AEE04_CODE'] ?? "";
            $data['ICD10_NAME'] = $patientRow['ICD10_NAME'];
            $data['ICD9_NAME'] = $patientRow['ICD9_NAME'];
            $data['is_artificial'] = 1;
            $data['created_at'] = $currentTime;
            $data['updated_at'] = $currentTime;
            $data['submit_user'] = $request->user()['id'];
            $lastId = ErrorV2::query()->insertGetId($data);

            $title = "运行首页整改通知提醒";
        } // 运行病例
        elseif ($data['cate'] == 1) {
            $res = CaseQuality::query()->where(["rule_id" => $ruleRow['id'], "JZHM" => $patientRow['MED_REC_ID']])->get()->toArray();
            $data['basis'] = "病历标题【】\n错误内容【".$data['notice']."】 "."\r\n"." 质控依据【".$data['basis']."】";
            if (!empty($res)) {
                //return ToolsService::returnData(1, [], '该规则的质控结果已存在，无法重复添加');
                //获取存在的质控的basis,示例：[["住院号：1234567890，住院时间：2025-01-01 10:00:00，住院科室：内科"]]，把现在的$data['basis']合并进去
                $exist_basis = json_decode($res[0]['basis'], true);
                $exist_basis[] = [$data['basis']];
                $data['basis'] = json_encode($exist_basis, 256);
            }else{
                $data['basis'] = json_encode([[$data['basis']]], 256);
            }
            $data['JZHM'] = $patientRow['MED_REC_ID'];//就诊号码
            $data['rule_id'] = $ruleRow['id'];//规则id
            $data['created_at'] = $currentTime;//创建时间
            $data['is_artificial'] = 1;//是否人工质控
            $data['AAC02C'] = $patientRow['AAC02C'];//出院科室
            $data['YQ_CODE'] = $patientRow['YQ_CODE'];//出院病区
            $data['BQ_CODE'] = $patientRow['BQ_CODE'];//出院病区
            $data['submit_user'] = $request->user()['id'];

            //如果res不为空，则更新
            if (!empty($res)) {
                CaseQuality::query()->where(["rule_id" => $ruleRow['id'], "JZHM" => $patientRow['MED_REC_ID']])->update($data);
                $lastId = $res[0]['id'];
                CaseQualityZm::query()->where(["rule_id" => $ruleRow['id'], "JZHM" => $patientRow['MED_REC_ID']])->update(['basis' => $data['basis']]);
            }else{
                $lastId = CaseQuality::query()->insertGetId($data);
                CaseQualityZm::query()->insertGetId($data);
            }
            

            $blbh = $request->post('blbh');
            if ($blbh) {
                CaseQualityDoctor::addData($blbh, $data);
            }

            $title = "运行病例整改通知提醒";
        }
        $jsr = explode(",", $data['JSR']);
        foreach ($jsr as $v) {
            QualitySendMsgLog::query()->insert(
                [
                    'zyh' => $patientRow["MED_REC_ID"], // 6位住院号
                    'AAA28' => $patientRow['AAA28'], // 8位住院号
                    'rule_id' => $ruleRow['id'], // 质控规则的ID
                    'content' => $basis, // 发送的钉钉信息内容
                    'quality_content' => $data['notice'], // 发送的钉钉信息内容
                    'status' => 2, // 整改状态、未整改
                    'is_warning_msg' => 2, // 整改状态、未整改
                    'doctor_id' => $v,
                    'title' => $title,
                    'AAC11N' => $patientRow['AAC02C'] ?? "", // 病人所属科室
                    'msg_yj' => $data['basis'], // 质控依据
                    'created_at' => time(),
                    'case_quality_id' => $lastId,
                    'quality_type' => $data['cate'],
                ]
            );
            CaseService::sendMsg($v, $data["basis"], $data['cate'], $title);
        }

        if (!$lastId) return ToolsService::returnData(1, [], '发送整改失败');
        return ToolsService::returnData(200, [], '发送整改成功');
    }
}
