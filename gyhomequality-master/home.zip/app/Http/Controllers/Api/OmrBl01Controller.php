<?php

namespace App\Http\Controllers\Api;

use App\Model\User;
use App\Model\Staff;
use App\Model\MS_BRDA;
use App\Model\YS_MZ_JZLS;
use App\Model\OmrRule;
use App\Model\OMR_BL01;
use App\Model\OMR_BLSY;
use App\Model\Department;
use App\Model\OmrDepartment;
use App\Services\CsvService;
use App\Services\UserService;
use Illuminate\Http\Request;
use App\Services\ToolsService;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use App\Services\ElasticsearchService;
use Illuminate\Support\Facades\Session;

class OmrBl01Controller extends Controller
{
    /**
     * 门诊病历搜索
     * @param Request $request
     * @return array
     */
    public function getOmrBl01List(Request $request)
    {
        $startTime = $request->post('start_time','');   // 开始时间
        $endTime = $request->post('end_time','');       // 结束时间
        $startNl = $request->post('start_nl','');   // 开始岁
        $endNl = $request->post('end_nl','');       // 结束岁
        $field = $request->post('field',[]);       // 搜索字段
        $page = $request->post('page',1);
        $pageSize = $request->post('page_size',10);
        $isTm = $request->post('is_tm', 0);
        $pageStart = ($page - 1) * $pageSize;
        if ($pageStart >= 10000) {
            if ($pageStart >= 10000) {
                $page = floor(10000 / $pageSize);
            }
            $page = ($page - 1);
        }

        $userDepId = UserService::getCurrentUserDep($request);
        if (empty($userDepId)) {
            return ToolsService::jsonSuccess(['count' => 0, 'list' => []]);
        }

        $userCode = $request->post('code', '');
        if ($userCode) {
            $userDepId = Staff::query()->where('YGBH','=',$userCode)->value('ksdm');
            if (empty($userDepId)) {
                $userDepId = Staff::query()->where('code','=',$userCode)->value('ksdm');
                $userDepId = [$userDepId];
            }
        }

        // 全文搜索关键字
        $must = [];

        if ($userDepId && is_array($userDepId)) {
            $depList = Department::query()->whereIn('dep_id', $userDepId)->pluck('dep_name')->toArray();
            if (!empty($depList)) {
                $must[] = ['terms' => ['ks.keyword' => $depList]];
            }
        }

        // 年龄匹配
        if ($startNl && $endNl) {
            $must[] = ['range' => ['nl' => ['gte' => $startNl,'lte' => $endNl]]];
        } elseif ($startNl) {
            $must[] = ['range' => ['nl' => ['gte' => $startNl]]];
        } elseif ($endNl) {
            $must[] = ['range' => ['nl' => ['lte' => $endNl]]];
        }

        // 就诊时间匹配
        if ($startTime && $endTime) {
            $startTime = date('Y-m-d',strtotime($startTime)).' 00:00:00';
            $endTime = date('Y-m-d',strtotime($endTime)).' 23:59:59';
            $must[] = ['range' => ['jzsj' => ['gte' => $startTime,'lte' => $endTime]]];
        } elseif ($startTime) {
            $startTime = date('Y-m-d',strtotime($startTime)).' 00:00:00';
            $must[] = ['range' => ['jzsj' => ['gte' => $startTime]]];
        } elseif ($endTime) {
            $endTime = date('Y-m-d',strtotime($endTime)).' 23:59:59';
            $must[] = ['range' => ['jzsj' => ['lte' => $endTime]]];
        }

        $notMust = [];
        $should = [];
        $BLNR_TXT_ARR = [];

        // 处理字段筛选
        if ($field) {
            foreach ($field as $value) {
                if ($value['key'] == 'BLNR_TXT') {
                    $BLNR_TXT_ARR[] = $value['value'];
                }

                if (!empty($value['value'])) {
                    // 处理特殊字段映射
                    $fieldKey = $value['key'];
                    if ($fieldKey == 'ks') {
                        $fieldKey = 'ks.keyword';
                        $value['value'] = Department::query()->where('dep_id', $value['value'])->value('dep_name');
                    }

                    // 根据字段类型选择合适的查询方式
                    $queryType = $this->getQueryTypeForField($fieldKey);

                    // 根据选择类型确定查询条件
                    if (isset($value['select_type']) && $value['select_type'] === 1) {
                        // OR 条件
                        $should[] = [$queryType => [$fieldKey => $value['value']]];
                    } else if (isset($value['select_type']) && $value['select_type'] == 2) {
                        // NOT 条件
                        $notMust[] = [$queryType => [$fieldKey => $value['value']]];
                    } else {
                        // AND 条件
                        $must[] = [$queryType => [$fieldKey => $value['value']]];
                    }
                }
            }
        }

        $omrBl01Service = new ElasticsearchService('omr_bl01_2023');
        if ($should) {
            $params = $omrBl01Service->clearMust()
                ->queryByMustBatch($must)
                ->queryByMustNot($notMust)
                ->queryByShouldBatch($should)
                ->minimumShouldMatch(1)
                ->highlight()
                ->paginate($page,$pageSize)
                ->trackTotalHits()
                ->getParams();
        } else {
            $params = $omrBl01Service->clearMust()
                ->queryByMustBatch($must)
                ->queryByMustNot($notMust)
                ->highlight()
                ->paginate($page,$pageSize)
                ->trackTotalHits()
                ->getParams();
        }
        $params['body']['sort'] = [['jzsj' => 'desc']];

        // 查询
        $restful = app('es')->search($params);
        $omrBl01List = $omrBl01Service->getDataByEs($restful);

        // 解析详情数据
        $omrBl01Ddetail = $omrBl01Service->getDataByEsToArray($restful);

        // 总条数
        $total = !empty($omrBl01List[1]) ? $omrBl01List[1] : 0;
        // 总页数
        $totalPage = 0;
        if ($total) {
            $totalPage = (int)ceil($total/$pageSize);
        }

        // 列表数据处理
        $list = [];
        if (!empty($omrBl01List[0])) {
            foreach ($omrBl01List[0] as $key => $value) {
                $isTm = $userDepId == 'admin' ? 0 : 1;
                // 身份证号脱敏
                $SFZH = $isTm ? desensitize($value['SFZH'], 6, 8) : $value['SFZH'];

                $msBrdaData = MS_BRDA::query()->where('BRID', '=', $value['BRID'])->first();
                if (empty($value['mzh']) && !empty($msBrdaData)) {
                    $value['mzh'] = $msBrdaData->MZHM;
                }
                if (empty($value['xm']) && !empty($msBrdaData)) {
                    $value['xm'] = $msBrdaData->BRXM;
                }
                if (empty($value['xb']) && !empty($msBrdaData)) {
                    $xbArr = [1=>'男',2=>'女'];
                    $value['xb'] = $xbArr[$msBrdaData->BRXB] ?? '';
                }

                $value['xm'] = $isTm ? desensitize($value['xm'], 1, 1) : $value['xm'];
                $list[] = [
                    'mzh' => $value['mzh'],
                    'xm' => $value['xm'],
                    'nl' => str_replace('-', '', $value['nl1']),
                    'xb' => $value['xb'],
                    'ks' => $value['ks'],
                    // 'ks' => $depData[$value['BRKS']] ?? $value['BRKS'],
                    'CJSJ' => $value['jzsj'],
                    'SFZH' => $SFZH,
                    'BLBH' => $value['BLBH'],
                    'BRID' => $value['BRID'],
                    'cbzd' => $value['cbzd'] ?? '',
                    'zs' => $value['zs'] ?? '',
                    'bl_type' => $value['bl_type'] ?? ''
                ];

                // 姓名脱敏
                $omrBl01Ddetail[0][$key]['xm'] = $value['xm'];
                $omrBl01Ddetail[0][$key]['SFZH'] = $SFZH;
            }
        }

        // 关键字高亮处理
        if (!empty($BLNR_TXT_ARR) && !empty($omrBl01Ddetail[0])) {
            foreach ($omrBl01Ddetail[0] as $key => $omrBl01Info) {
                foreach ($omrBl01Info as $k => $val) {
                    $newValue = $val;
                    foreach ($BLNR_TXT_ARR as $keyword) {
                        $newValue = str_replace($keyword,"<font color='red'>".$keyword."</font>",$newValue);
                    }
                    $omrBl01Ddetail[0][$key][$k] = $newValue;
                }
            }
        }

        // 返回数据
        $returnData = [
            'total_page' => $totalPage,
            'total' => $total,
            'list' => $list,
            'detail' => $omrBl01Ddetail[0] ?? []
        ];

        return ToolsService::returnData(200, $returnData, $msg ?? '');
    }

    /**
     * 根据字段类型获取合适的查询方式
     * @param string $fieldKey
     * @return string
     */
    private function getQueryTypeForField($fieldKey)
    {
        // 根据字段类型选择合适的查询方式
        $keywordFields = ['SFZH', 'mzh', 'xb', 'bl_type', 'SXYS', 'BLZT', 'DLJ', 'DLLB', 'tx', 'nl1', 'ks'];
        $integerFields = ['BLBH', 'BLLB', 'BLLX', 'BRID', 'BRKS', 'id', 'is_defect', 'JZXH', 'nl', 'SXKS'];
        $dateFields = ['CJSJ', 'JLSJ', 'WCSJ', 'jzsj'];

        if (in_array($fieldKey, $keywordFields)) {
            return 'term';
        } elseif (in_array($fieldKey, $integerFields)) {
            return 'term';
        } elseif (in_array($fieldKey, $dateFields)) {
            return 'range';
        } else {
            // 默认使用全文搜索
            return 'match_phrase';
        }
    }

    /**
     * 门诊病历质控 - 质量分析
     * @param Request $request
     * @return array
     */
    public function analysis(Request $request)
    {
        $startTime = $request->post('start_time','');   // 开始时间
        $endTime = $request->post('end_time','');       // 结束时间

        $must = [];
        if ($startTime) {
            $startTime = date('Y-m-d', strtotime($startTime)).' 00:00:00';
            $must[] = ['range' => ['jzsj' => ['gte' => $startTime]]];
        }
        if ($endTime) {
            $endTime = date('Y-m-d', strtotime($endTime)).' 23:59:59';
            $must[] = ['range' => ['jzsj' => ['lte'=>$endTime]]];
        }

        // 查询所有门诊病历
        $omrBl01Service = new ElasticsearchService('omr_bl01_2023');
        $params = $omrBl01Service->clearMust()
            ->queryByMustBatch($must)
            ->queryByMust(['term'=>['BLZT'=>1]])
            ->trackTotalHits()
            ->getParams();
        $restful = app('es')->search($params);
        $data = $omrBl01Service->getDataByEs($restful);
        $returnData['omr_total'] = !empty($data[1]) ? $data[1] : 0;


        // 就诊人次
        $jzlsQuery = YS_MZ_JZLS::query()->where('JZZT', 9);
        if (!empty($startTime)) {
            $jzlsQuery->where('KSSJ', '>=', $startTime);
        }
        if (!empty($endTime)) {
            $jzlsQuery->where('KSSJ', '<=', $endTime);
        }
        $jzlsData = $jzlsQuery->count();

        $returnData['should_be_total'] = $jzlsData;

        // 查询有缺陷门诊病历
        $must[] = ['term' => ['is_defect'=>1]];
        $params = $omrBl01Service->clearMust()
            ->queryByMustBatch($must)
            ->trackTotalHits()
            ->getParams();
        $restful = app('es')->search($params);
        $data = $omrBl01Service->getDataByEs($restful);
        $returnData['omr_defect_total'] = !empty($data[1]) ? $data[1] : 0;

        return ToolsService::returnData(200, $returnData, '');
    }

    /**
     * 门诊病历质控 - 科室排名
     * @param Request $request
     * @return array
     */
    public function rankingDepartment(Request $request)
    {
        $startTime = $request->post('start_time','');   // 开始时间
        $endTime = $request->post('end_time','');       // 结束时间

        // 获取科室信息
        $department = OmrDepartment::getOmrDepartmentData();

        $omrBl01Service = new ElasticsearchService('omr_bl01_2023');
        $must = [];
        if ($startTime && $endTime) {
            $startTime = date('Y-m-d', strtotime($startTime)).' 00:00:00';
            $endTime = date('Y-m-d', strtotime($endTime)).' 23:59:59';
            $must[] = ['range' => ["jzsj" => ['gte' => $startTime, 'lte' => $endTime]]];
        } elseif ($startTime) {
            $startTime = date('Y-m-d', strtotime($startTime)).' 00:00:00';
            $must[] = ['range' => ["jzsj" => ['gte' => $startTime]]];
        } elseif ($endTime) {
            $endTime = date('Y-m-d', strtotime($endTime)).' 23:59:59';
            $must[] = ['range' => ["jzsj" => ['lte' => $endTime]]];
        }

        $aggs = ['BRKS' => ['terms' => ["field" => 'BRKS', "size" => 500]]];
        // 查询科室下所有病历
        $params = $omrBl01Service->clearMust()
            ->queryByMustBatch($must)
            ->aggs($aggs)
            ->paginate(1, 0)
            ->getParams();
        $restful = app('es')->search($params);
        $dataAll = $omrBl01Service->getDataByEs($restful);
        $dataAll = !empty($dataAll[2]['BRKS']['buckets']) ? $dataAll[2]['BRKS']['buckets'] : [];
        $dataAll = array_column($dataAll, null, 'key');

        // 查询科室下有缺陷的病历
        $must[] = ['term' => ['is_defect' => 1]];
        $params = $omrBl01Service->clearMust()
            ->queryByMustBatch($must)
            ->aggs($aggs)
            ->paginate(1, 0)
            ->getParams();
        $restful = app('es')->search($params);
        $dataQx = $omrBl01Service->getDataByEs($restful);
        $dataQx = !empty($dataQx[2]['BRKS']['buckets']) ? $dataQx[2]['BRKS']['buckets'] : [];
        $dataQx = array_column($dataQx, null, 'key');

        $depData = [];
        foreach ($dataAll as $key => $value) {
            $depData[] = [
                'name' => $department[$key] ?? $key,
                'total_medical' => $value['doc_count'] ?? 0,
                'total_error_medical' => $dataQx[$key]['doc_count'] ?? 0,
            ];
        }

        $depData = $this->arraySort($depData, 'total_error_medical', 4);
        $returnData = [];
        foreach ($depData as $key => $value) {
            if ($key > 9) {
                break;
            }
            $returnData[] = $value;
        }

        return ToolsService::returnData(200, $returnData, '');
    }

    /**
     * 门诊病历质控 - 缺陷问题
     * @param Request $request
     * @return array
     */
    public function defectIssues(Request $request)
    {
        $startTime = $request->post('start_time','');   // 开始时间
        $endTime = $request->post('end_time','');       // 结束时间

        $omrQualityService = new ElasticsearchService('omr_quality_2023');

        $omrRuleData = OmrRule::query()->get()->toArray();
        $returnData = [];
        foreach ($omrRuleData as $ruleInfo) {
            $must = [
                ['term' => ['rule_id'=>$ruleInfo['id']]]
            ];
            if ($startTime && $endTime) {
                $startTime = date('Y-m-d', strtotime($startTime)).' 00:00:00';
                $endTime = date('Y-m-d', strtotime($endTime)).' 23:59:59';
                $must[] = ['range' => ['jzsj.keyword' => ['gte' => $startTime,'lte'=>$endTime]]];
            } elseif ($startTime) {
                $startTime = date('Y-m-d', strtotime($startTime)).' 00:00:00';
                $must[] = ['range' => ['jzsj.keyword' => ['gte' => $startTime]]];
            } elseif ($endTime) {
                $endTime = date('Y-m-d', strtotime($endTime)).' 23:59:59';
                $must[] = ['range' => ['jzsj.keyword' => ['lte'=>$endTime]]];
            }

            $params = $omrQualityService->clearMust()
                ->queryByMustBatch($must)
                ->trackTotalHits()
                ->getParams();
            $restful = app('es')->search($params);
            $data = $omrQualityService->getDataByEs($restful);
            if (empty($data[1])) {
                continue;
            }
            $returnData[] = [
                'rule_id' => $ruleInfo['id'],
                'field' => $ruleInfo['title'],
                'desc' => $ruleInfo['notice'],
                'total_num' => $data[1],
            ];
        }

        $returnData = $this->arraySort($returnData,'total_num');

        return ToolsService::returnData(200, $returnData, '');
    }

    /**
     * 缺陷列表
     * @param Request $request
     * @return array
     */
    public function errorList(Request $request)
    {
        $ruleId = $request->post('rule_id','');         // 规则ID
        $depId = $request->post('dep_id','');           // 科室ID
        $sfzh = $request->post('sfzh','');              // 身份证号
        $doctorId = $request->post('doctor_id','');     // 医生签名
        $startTime = $request->post('start_time','');   // 开始时间
        $endTime = $request->post('end_time','');       // 结束时间
        $isError = $request->post('is_error',1);        // 是否查询错误信息
        $mzh = $request->post('mzh','');                // 门诊号
        $page = $request->post('page',1);
        $pageSize = $request->post('page_size',10);

        $must = [];
        // 质控规则ID
        if ($ruleId) {
            $must[] = ['term' => ['rule_id' => $ruleId]];
        }
        // 病人科室ID
        if ($depId) {
            $must[] = ['term' => ['BRKS' => $depId]];
        }
        // 身份证号
        if ($sfzh) {
            $must[] = ['term' => ['SFZH' => $sfzh]];
        }
        // 书写医生ID
        if ($doctorId) {
            $must[] = ['term' => ['SXYS' => $doctorId]];
        }
        // 门诊号
        if ($mzh) {
            $must[] = ['match_phrase' => ['mzh' => $mzh]];
        }
        // 就诊时间
        if ($startTime && $endTime) {
            $startTime = date('Y-m-d', strtotime($startTime)).' 00:00:00';
            $endTime = date('Y-m-d', strtotime($endTime)).' 23:59:59';
            $must[] = ['range' => [(($isError && $ruleId) ? 'jzsj.keyword' : 'jzsj') => ['gte' => $startTime, 'lte' => $endTime]]];
        } elseif ($startTime) {
            $startTime = date('Y-m-d', strtotime($startTime)).' 00:00:00';
            $must[] = ['range' => [(($isError && $ruleId) ? 'jzsj.keyword' : 'jzsj') => ['gte' => $startTime]]];
        } elseif ($endTime) {
            $endTime = date('Y-m-d', strtotime($endTime)).' 23:59:59';
            $must[] = ['range' => [(($isError && $ruleId) ? 'jzsj.keyword' : 'jzsj') => ['lte' => $endTime]]];
        }

        $omrQualityService = new ElasticsearchService('omr_quality_2023');
        $omrBl01Service = new ElasticsearchService('omr_bl01_2023');

        if ($isError && $ruleId) {
            $params = $omrQualityService->clearMust()
                ->queryByMustBatch($must)
                ->paginate($page,$pageSize)
                ->trackTotalHits()
                ->getParams();
            $restful = app('es')->search($params);
            $data = $omrQualityService->getDataByEs($restful);
        } else {
            if ($isError) {
                $must[] = ['term' => ['is_defect' => 1]];
            }
            $params = $omrBl01Service->clearMust()
                ->queryByMustBatch($must)
                ->paginate($page,$pageSize)
                ->trackTotalHits()
                ->getParams();
            $restful = app('es')->search($params);
            $data = $omrBl01Service->getDataByEs($restful);
        }

        $list = [];
        if ($data[0]) {
            // 获取科室
//            $department = OmrDepartment::getOmrDepartmentData();
            $department = Department::getDepartmentData();
            foreach ($data[0] as $value) {
                if (!empty($value['SFZH'])) {
                    // 身份证号脱敏
                    $value['SFZH'] = desensitize($value['SFZH'],6,8);
                }

                // 病人科室
                if(!empty($value["ks"])){
                    $value['dep_name'] = $value["ks"];
                }else{
                    $value['dep_name'] = $department[$value['BRKS']] ?? $value['BRKS'];
                }

                // 医生签名
                if (!empty($value['SXYS'])) {
                    $staffData = Staff::query()->where('code',$value['SXYS'])->first();
                    $value['SXYS_NAME'] = !empty($staffData) ? $staffData->name : '';
                }

                $list[] = $value;
            }
        }

        $returnData = [
            'list' => $list,
            'count' => $data[1]
        ];

        return ToolsService::returnData(200, $returnData, '');
    }

    /**
     * 缺陷列表导出
     * @param Request $request
     * @return string|null
     */
    public function errorListExport(Request $request)
    {
        $ruleId = $request->post('rule_id','');         // 规则ID
        $depId = $request->post('dep_id','');           // 科室ID
        $sfzh = $request->post('sfzh','');              // 身份证号
        $doctorId = $request->post('doctor_id','');     // 医生签名
        $startTime = $request->post('start_time','');   // 开始时间
        $endTime = $request->post('end_time','');       // 结束时间
        $isError = $request->post('is_error',1);        // 是否查询错误信息
        $mzh = $request->post('mzh','');                // 门诊号

        $must = [];
        // 质控规则ID
        if ($ruleId) {
            $must[] = ['term' => ['rule_id' => $ruleId]];
        }
        // 病人科室ID
        if ($depId) {
            $must[] = ['term' => ['BRKS' => $depId]];
        }
        // 身份证号
        if ($sfzh) {
            $must[] = ['term' => ['SFZH' => $sfzh]];
        }
        // 书写医生ID
        if ($doctorId) {
            $must[] = ['term' => ['SXYS' => $doctorId]];
        }
        // 门诊号
        if ($mzh) {
            $must[] = ['match_phrase' => ['mzh' => $mzh]];
        }
        // 就诊时间
        if ($startTime && $endTime) {
            $startTime = date('Y-m-d', strtotime($startTime)).' 00:00:00';
            $endTime = date('Y-m-d', strtotime($endTime)).' 23:59:59';
            $must[] = ['range' => ['jzsj' => ['gte' => $startTime, 'lte' => $endTime]]];
        } elseif ($startTime) {
            $startTime = date('Y-m-d', strtotime($startTime)).' 00:00:00';
            $must[] = ['range' => ['jzsj' => ['gte' => $startTime]]];
        } elseif ($endTime) {
            $endTime = date('Y-m-d', strtotime($endTime)).' 23:59:59';
            $must[] = ['range' => ['jzsj' => ['lte' => $endTime]]];
        }

        $omrQualityService = new ElasticsearchService('omr_quality_2023');
        $omrBl01Service = new ElasticsearchService('omr_bl01_2023');
        $staffService = new ElasticsearchService('staff_2023');

        if ($isError && $ruleId) {
            $params = $omrQualityService->clearMust()
                ->queryByMustBatch($must)
                ->source(['jzsj','mzh','xm','BRKS','xb','nl','cbzd','SFZH','SXYS'])
                ->paginate(1,1000000)
                ->trackTotalHits()
                ->getParams();
            $restful = app('es')->search($params);
            $data = $omrQualityService->getDataByEs($restful);
        } else {
            $params = $omrBl01Service->clearMust()
                ->queryByMustBatch($must)
                ->source(['jzsj','mzh','xm','BRKS','xb','nl','cbzd','SFZH','SXYS'])
                ->paginate(1,1000000)
                ->trackTotalHits()
                ->getParams();
            $restful = app('es')->search($params);
            $data = $omrBl01Service->getDataByEs($restful);
        }

        $list[] = ['就诊时间','门诊号','姓名','科室','性别','年龄','初步诊断','身份证号','医生签名'];
        if (!empty($data[0])) {
            $data = $data[0];
            // 获取科室
            $department = OmrDepartment::getOmrDepartmentData();
            // 获取医生
            $doctorList = Staff::query()->pluck('name','code')->toArray();
            foreach ($data as $value) {
                // 姓名脱敏
                $value['xm'] = desensitize($value['xm'],1,2);

                // 身份证号脱敏
                if (!empty($value['SFZH'])) {
                    $value['SFZH'] = desensitize($value['SFZH'],6,8);
                }

                // 病人科室
                $value['BRKS'] = $department[$value['BRKS']] ?? $value['BRKS'];

                // 医生签名
                if (!empty($value['SXYS'])) {
                    $value['SXYS'] = $doctorList[$value['SXYS']] ?? $value['SXYS'];
                }

                $list[] = [
                    'jzsj' => $value['jzsj'],
                    'mzh' => $value['mzh'],
                    'xm' => $value['xm'],
                    'BRKS' => $value['BRKS'],
                    'xb' => $value['xb'],
                    'nl' => $value['nl'],
                    'cbzd' => $value['cbzd'],
                    'SFZH' => $value['SFZH'],
                    'SXYS' => $value['SXYS'],
                ];
            }
        }

        $csv = new CsvService();
        $csv->filename = $csv->charset('缺陷列表导出', 'UTF-8');

        return $csv->export($list, false);
    }

    /**
     * 获取医生列表
     * @param Request $request
     * @return array
     */
    public function getDoctorList(Request $request)
    {
        $doctorName = $request->post('doctor_name','');
        $where = [];
        if ($doctorName) {
            $where[] = ['name','like',"%".$doctorName."%"];
        }
        $doctorData = Staff::query()->where($where)->get(['code as id','name'])->toArray();

        return ToolsService::returnData(200, $doctorData, '');
    }

    /**
     * 获取科室列表
     * @param Request $request
     * @return array
     */
    public function getDepartmentList(Request $request)
    {
        $depName = $request->post('dep_name','');
        $where = [
            ['dep_id', '>', 0],
            ['dep_name', '!=', ''],
            ['status', '=', 0]
        ];
        if ($depName) {
            $where[] = ['dep_name','like',"%".$depName."%"];
        }
        $departmentList = Department::query()
            ->where($where)
            ->get(['dep_id as id','dep_name as name'])->toArray();

        return ToolsService::returnData(200, $departmentList, '');
    }

    /**
     * 门诊号获取（去重）
     * @param Request $request
     * @return array
     */
    public function getMzh(Request $request)
    {
        return OMR_BL01::query()->groupBy('mzh')->pluck('mzh')->toArray();
    }

    /**
     * 二维数组排序
     * @param $array
     * @param $keys
     * @param $sort
     * @return mixed
     */
    public function arraySort($array, $keys, $sort = SORT_DESC)
    {
        $keysValue = [];
        foreach ($array as $k => $v) {
            $keysValue[$k] = $v[$keys];
        }
        array_multisort($keysValue, $sort, $array);
        return $array;
    }

    /**
     * 门诊 - 搜索类型获取
     * @param Request $request
     * @return array
     */
    public function serachTypeList(Request $request)
    {
        $serachList = [
            ['key' => 'BLNR_TXT', 'value' => '全文'],
            ['key' => 'xy', 'value' => '西药'],
            ['key' => 'mzh', 'value' => '门诊号'],
            ['key' => 'ks', 'value' => '科室'],
            ['key' => 'xb', 'value' => '性别'],
            ['key' => 'xm', 'value' => '姓名'],
            // ['key' => 'SFZH', 'value' => '身份证号'],
            ['key' => 'zs', 'value' => '主诉'],
            ['key' => 'xbs', 'value' => '现病史'],
            ['key' => 'jws', 'value' => '既往史'],
            ['key' => 'cbzd', 'value' => '初步诊断'],
            ['key' => 'tgjc', 'value' => '体格检查'],
            ['key' => 'fzjc', 'value' => '辅助检查'],
            ['key' => 'zlyj', 'value' => '诊疗意见'],
            // ['key' => 'bl_type', 'value' => '病历类型']
        ];

        return ToolsService::returnData(200, $serachList, '');
    }

    /**
     * 门诊病历详情接口
     * @param Request $request
     * @return array
     */
    public function omrInfo(Request $request)
    {
        $blbh = $request->post('blbh','');

        if (empty($blbh)) {
            return ToolsService::returnData(4001, '参数错误', $msg ?? '');
        }
        $userDepId = UserService::getCurrentUserDep($request);
        $isTm = $userDepId == 'admin' ? 0 : 1;

        $omrBl01Service = new ElasticsearchService('omr_bl01_2023');
        $must = ['term' => ['BLBH'=>$blbh]];
        $params = $omrBl01Service->clearMust()
            ->queryByMust($must)
            ->getParams();
        $restful = app('es')->search($params);
        $data = $omrBl01Service->getDataByEs($restful);
        $omrInfo = [];
        if (!empty($data[0])) {
            $data = $data[0][0];
            // 表头处理
            $title = '急诊病历';
            $subtitle = '';
            $array = explode('滨州医学院烟台附属医院',$data['BLNR_TXT']);
            if (!empty($array[1])) {
                if (stripos($array[1],'初诊') !== false) {
                    $title = '门诊病历';
                    $subtitle = '初诊';
                } elseif (stripos($array[1],'复诊') !== false) {
                    $title = '门诊病历';
                    $subtitle = '复诊';
                }
            }

            // 查询签名医生信息
            $SYYS = OMR_BLSY::query()
                ->where('BLBH','=',$data['BLBH'])
                ->pluck('SYYS')->toArray();
            $doctorName = '';
            if ($SYYS) {
                $staffList = Staff::query()->whereIn('code',$SYYS)->get(['name','ygjb_text'])->toArray();
                $nameList = [];
                foreach ($staffList as $staffInfo) {
                    $nameList[] = $staffInfo['name']."（".$staffInfo['ygjb_text']."）";
                }
                $doctorName = implode('、', $nameList);
            }
            // 查询书写医生
            $staffList = Staff::query()->where( function ($query) use ($data) {
                $query->where('code',$data['SXYS'])
                    ->orWhere('YGBH',$data['SXYS']);
            })->get(['name','ygjb_text'])->toArray();
            $SXYS_NAME = !empty($staffList[0]['name']) ? $staffList[0]['name'].'（'.$staffList[0]['ygjb_text'].'）' : $data['SXYS'];

            $zlyj = !empty($data['zlyj']) ? explode("\n",$data['zlyj']) : [];
            $xy = !empty($data['xy']) ? explode("\n",$data['xy']) : [];
            $omrInfo = [
                'title' => $title,
                'subtitle' => $subtitle,
                'mzh' => $data['mzh'],
                'xm' => $isTm ? desensitize($data['xm'], 1, 1) : $data['xm'],
                'jzsj' => $data['jzsj'],
                'ks' => $data['ks'],
                'xb' => $data['xb'],
                'nl' => $data['nl'],
                'nl1' => $data['nl1'],
                'zs' => $data['zs'],
                'xbs' => $data['xbs'],
                'jws' => $data['jws'],
                'tgjc' => $data['tgjc'],
                'fzjc' => $data['fzjc'],
                'cbzd' => $data['cbzd'],
                'zlyj' => $zlyj,
                'xy' => $xy,
                'SXYS' => $SXYS_NAME,
                'doctor_name' => $doctorName
            ];
        }

        return ToolsService::returnData(200, $omrInfo, '');
    }

    /**
     * 获取门诊病历质控结果
     * @param Request $request
     * @return array
     */
    public function getOmrQuality(Request $request)
    {
        $blbh = $request->post('blbh','');

        if (empty($blbh)) {
            return ToolsService::returnData(4001, '参数错误', $msg ?? '');
        }

        $omrQualityService = new ElasticsearchService('omr_quality_2023');
        $must = [
            ['term' => ['BLBH' => $blbh]]
        ];
        $params = $omrQualityService->clearMust()
            ->queryByMustBatch($must)
            ->paginate(1,1000)
            ->getParams();
        $restful = app('es')->search($params);
        $omrQualityData = $omrQualityService->getDataByEs($restful);
        $returnData = [];
        $score = 100;
        if (!empty($omrQualityData[0])) {
            foreach ($omrQualityData[0] as $value) {
                $omrRule = OmrRule::query()->find($value['rule_id']);
                if ($omrRule) {
                    $score -= $omrRule->score;
                    $value['score'] = $omrRule->score;
                    $value['notice'] = $omrRule->notice;
                    $value['basis'] = json_decode($value['basis'], true);
                    $returnData[$omrRule->category][] = $value;
                }
            }
        }

        return ToolsService::returnData(200, ['score'=>$score,'data'=>$returnData], $msg ?? '');
    }

    /**
     * 应有门诊病历列表
     * @param Request $request
     * @return array
     */
    public function getShouldBeBlList(Request $request)
    {
        $depId = $request->post('dep_id','');           // 科室ID
        $sfzh = $request->post('sfzh','');              // 身份证号
        $doctorId = $request->post('doctor_id','');     // 医生签名
        $startTime = $request->post('start_time','');   // 开始时间
        $endTime = $request->post('end_time','');       // 结束时间
        $mzh = $request->post('mzh','');                // 门诊号
        $page = $request->post('page',1);
        $pageSize = $request->post('page_size',10);

        $must = [];
        // 病人科室ID
        if ($depId) {
            $must[] = ['term' => ['BRKS' => $depId]];
        }
        // 身份证号
        if ($sfzh) {
            $must[] = ['term' => ['SFZH' => $sfzh]];
        }
        // 书写医生ID
        if ($doctorId) {
            $must[] = ['term' => ['SXYS' => $doctorId]];
        }
        // 门诊号
        if ($mzh) {
            $must[] = ['match_phrase' => ['mzh' => $mzh]];
        }
        // 就诊时间
        if ($startTime && $endTime) {
            $startTime = date('Y-m-d', strtotime($startTime)).' 00:00:00';
            $endTime = date('Y-m-d', strtotime($endTime)).' 23:59:59';
            $must[] = ['range' => ['jzsj' => ['gte' => $startTime, 'lte' => $endTime]]];
        } elseif ($startTime) {
            $startTime = date('Y-m-d', strtotime($startTime)).' 00:00:00';
            $must[] = ['range' => ['jzsj' => ['gte' => $startTime]]];
        } elseif ($endTime) {
            $endTime = date('Y-m-d', strtotime($endTime)).' 23:59:59';
            $must[] = ['range' => ['jzsj' => ['lte' => $endTime]]];
        }

        $omrQualityUniqueService = new ElasticsearchService('omr_bl01_2023');
        $staffService = new ElasticsearchService('staff_2023');

        $params = $omrQualityUniqueService->clearMust()
            ->queryByMustBatch($must)
            ->paginate($page,$pageSize)
            ->trackTotalHits()
            ->getParams();
        $restful = app('es')->search($params);
        $data = $omrQualityUniqueService->getDataByEs($restful);

        $list = [];
        if ($data[0]) {
            // 获取科室
            $department = OmrDepartment::query()->pluck('dep_name','dep_id')->toArray();
            foreach ($data[0] as $value) {
                if ($value['SFZH']) {
                    // 身份证号脱敏
                    $value['SFZH'] = desensitize($value['SFZH'],6,8);
                }

                // 病人科室
                if($value["ks"]){
                    $value['dep_name'] = $value["ks"];
                }else{
                    $value['dep_name'] = $department[$value['BRKS']] ?? $value['BRKS'];
                }

                // 医生签名
                if ($value['SXYS']) {
                    $must = [
                        ['term' => ['code'=>$value['SXYS']]]
                    ];
                    $params = $staffService->clearMust()
                        ->queryByMustBatch($must)
                        ->getParams();
                    $restful = app('es')->search($params);
                    $staffData = $staffService->getDataByEs($restful);
                    $value['SXYS_NAME'] = !empty($staffData[0][0]['name']) ? $staffData[0][0]['name'] : '';
                }

                $list[] = $value;
            }
        }

        $returnData = [
            'list' => $list,
            'count' => $data[1]
        ];

        return ToolsService::returnData(200, $returnData, '');
    }

    /**
     * 应有门诊病历导出
     * @param Request $request
     * @return string|null
     */
    public function getShouldBeBlExport(Request $request)
    {
        $depId = $request->post('dep_id','');           // 科室ID
        $sfzh = $request->post('sfzh','');              // 身份证号
        $doctorId = $request->post('doctor_id','');     // 医生签名
        $startTime = $request->post('start_time','');   // 开始时间
        $endTime = $request->post('end_time','');       // 结束时间
        $mzh = $request->post('mzh','');                // 门诊号

        $must = [];
        // 病人科室ID
        if ($depId) {
            $must[] = ['term' => ['BRKS' => $depId]];
        }
        // 身份证号
        if ($sfzh) {
            $must[] = ['term' => ['SFZH' => $sfzh]];
        }
        // 书写医生ID
        if ($doctorId) {
            $must[] = ['term' => ['SXYS' => $doctorId]];
        }
        // 门诊号
        if ($mzh) {
            $must[] = ['match_phrase' => ['mzh' => $mzh]];
        }
        // 就诊时间
        if ($startTime && $endTime) {
            $startTime = date('Y-m-d', strtotime($startTime)).' 00:00:00';
            $endTime = date('Y-m-d', strtotime($endTime)).' 23:59:59';
            $must[] = ['range' => ['jzsj' => ['gte' => $startTime, 'lte' => $endTime]]];
        } elseif ($startTime) {
            $startTime = date('Y-m-d', strtotime($startTime)).' 00:00:00';
            $must[] = ['range' => ['jzsj' => ['gte' => $startTime]]];
        } elseif ($endTime) {
            $endTime = date('Y-m-d', strtotime($endTime)).' 23:59:59';
            $must[] = ['range' => ['jzsj' => ['lte' => $endTime]]];
        }

        $omrQualityUniqueService = new ElasticsearchService('omr_quality_unique_2023');
        $staffService = new ElasticsearchService('staff_2023');

        $params = $omrQualityUniqueService->clearMust()
            ->queryByMustBatch($must)
            ->source(['BLBH','jzsj','mzh','xm','BRKS','xb','nl','cbzd','SFZH','SXYS'])
            ->paginate(1,10000000)
            ->trackTotalHits()
            ->getParams();
        $restful = app('es')->search($params);
        $data = $omrQualityUniqueService->getDataByEs($restful);

        $list = [];
        $list[] = ['病历病号','就诊时间','门诊号','姓名','科室','性别','年龄','初步诊断','身份证号','医生'];
        if ($data[0]) {
            // 获取科室
            $department = OmrDepartment::query()->pluck('dep_name','dep_id')->toArray();
            foreach ($data[0] as $value) {
                if ($value['SFZH']) {
                    // 身份证号脱敏
                    $value['SFZH'] = desensitize($value['SFZH'],6,8);
                }

                // 病人科室
                $value['BRKS'] = $department[$value['BRKS']] ?? $value['BRKS'];

                // 医生签名
                if ($value['SXYS']) {
                    $must = [
                        ['term' => ['code'=>$value['SXYS']]]
                    ];
                    $params = $staffService->clearMust()
                        ->queryByMustBatch($must)
                        ->getParams();
                    $restful = app('es')->search($params);
                    $staffData = $staffService->getDataByEs($restful);
                    $value['SXYS'] = !empty($staffData[0][0]['name']) ? $staffData[0][0]['name'] : '';
                }

                $list[] = $value;
            }
        }

        $csv = new CsvService();
        $csv->filename = $csv->charset('应有门诊病历导出', 'UTF-8');

        return $csv->export($list, false);
    }

    /**
     * 获取门诊科室
     * @return array
     */
    public function getOmrDepartmentList()
    {
//        $depData = OmrDepartment::getOmrDepartmentData();
        $depData = Department::getOmrDepartmentData();

        $data = [];
        foreach ($depData as $key => $value) {
            $data[] = ['id'=>$key,'name'=>$value];
        }

        return ToolsService::returnData(200, $data, '');
    }

}
