<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Model\Department;
use App\Model\User;
use App\Services\ToolsService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

class LoginController extends Controller
{
    /**
     * login
     * @group Index
     * @bodyParam name string required 用户名
     * @bodyParam password string required 密码
     * @param Request $request
     * @response {
     *  "code":200,
     *  "msg":"",
     *  "data":{
     *      "token": "jkjhdjkshkjsj"
     *  },
     *  "time":123787842
     * }
     */
    public function login(Request $request)
    {
        $name = $request->post('name');
        $password = $request->post('password');
        $department_id = $request->post('department_id');
        if (!$name && !$password) {
            $name = $request->get('name');
            $password = $request->get('password');
            $department_id = $request->get('department_id');
        }
        $user = User::query()
            ->where('name', $name)
            ->whereNull('deleted_at')
            ->first(['id', 'name', 'password', 'group_id', 'status', 'realname','dep_id', 'w_id', 's_id', 'department_review']);
        if (!$user) {
            $code = 4001;
            $data = [];
            $msg = '登录失败，用户名或密码不正确，请重新输入';
        } else {
            $result = $user->toArray();
            $token = md5($result['name'] . $result['password']);
            Session::put($token, $result);
            Session::put($token . '_department_id', $department_id);
            if ($result['password'] == md5($password)) {
                // 密码正确，清除失败次数记录
                Session::forget('login_failed_' . $name);
                User::updateLogin($result['id'], $token, date("Y-m-d H:i:s"), request()->getClientIp());
                $code = 200;
                $data = ['token' => $token, 'realname' => $result['realname'], 'group_id' => $result['group_id'], "name"=>$result["name"], "id"=>$result["id"]];
                $msg = '';
            } else {
                // 密码错误，记录失败次数
                $failedKey = 'login_failed_' . $name;
                $failedAttempts = Session::get($failedKey, []);
                $currentTime = time();
                
                // 清除一分钟前的失败记录
                $failedAttempts = array_filter($failedAttempts, function($timestamp) use ($currentTime) {
                    return ($currentTime - $timestamp) <= 60;
                });
                
                // 添加当前失败记录
                $failedAttempts[] = $currentTime;
                Session::put($failedKey, $failedAttempts);
                
                // 检查是否达到3次失败
                if (count($failedAttempts) >= 3) {
                    // 锁定账户
                    User::where('id', $result['id'])->update(['status' => 1]);
                    $code = 4001;
                    $data = [];
                    $msg = '登录失败，账户已锁定';
                } else {
                    $code = 4001;
                    $data = [];
                    $msg = '登录失败，用户名或密码不正确，请重新输入';
                }
            }
            if ($result['status'] == 1) {
                $data = [];
                $code = 4001;
                $msg = '登录失败，账户已锁定';
            }
        }
        return ToolsService::returnData($code, $data, $msg);
    }

    public function thirdLogin(Request $request)
    {
        $name = $request->post('name');
        if(!$name){
            return ToolsService::returnData(4001, [], '请输入工号！！');
        }
        $user = User::query()
            ->where('name', $name)
            ->whereNull('deleted_at')
            ->first(['id', 'name', 'password', 'group_id', 'status', 'realname','dep_id', 'w_id', 's_id', 'department_review']);
        if (!$user || $user->status == 1) return ToolsService::returnData(4001, [], '用户不存在或已停用');
        $result = $user->toArray();
        if($user->realname !== '超级管理员') {
            $depId = json_decode($result['dep_id'], true);
            if (empty($depId)) return ToolsService::returnData(4001, [], '权限不足,请联系管理员处理!!');
            $dep = Department::query()->select('type_id')->whereIn("dep_id", $depId)->groupBy('type_id')->get()->toArray();
            $dep_array = data_get($dep, "*.type_id", []);
            if (!in_array(2, $dep_array) && !in_array(4, $dep_array)) {
                return ToolsService::returnData(4001, [], '权限不足,请联系管理员处理~');
            }
        }
        $token = md5($result['name'] . $result['password']);
        Session::put($token,$user);
        User::updateLogin($user['id'], $token, date("Y-m-d H:i:s"), request()->getClientIp());
        return ToolsService::returnData(200, [
            'token' => $token,
            'realname' => $result['realname'],
            'group_id' => $result['group_id'],
            "name"=>$result["name"],
            "id"=>$result["id"]], '');
    }

    /**
     * 退出登录
     * @param Request $request
     * @return array
     */
    public function logout(Request $request)
    {
        $token = $request->header('token');
        if (empty($token)) {
            return ToolsService::returnData(200, [], '');
        }

        Session::put($token,[]);

        return ToolsService::returnData(200, [], '');
    }


}
