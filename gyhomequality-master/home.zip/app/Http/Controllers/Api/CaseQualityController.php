<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Service\ExportService;
use App\Http\Service\FrontDataService;
use App\Model\CaseQuality;
use App\Model\CaseRule;
use App\Model\Department;
use App\Model\DepartmentData;
use App\Model\EMR_BL_BL01;
use App\Model\Error;
use App\Model\ErrorData;
use App\Model\FeeDetailed;
use App\Model\PatientHospitalInfo;
use App\Model\PatientInfo;
use App\Services\CoderService;
use App\Services\DepartmentService;
use App\Services\ElasticsearchService;
use App\Services\ErrorRuleService;
use App\Services\ExportWTAndGKService;
use App\Services\QualityService;
use App\Services\ToolsService;
use App\Services\DebugItemsService;
use App\Services\CaseQualityService;
use App\Services\UserService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Maatwebsite\Excel\Facades\Excel;
use App\Exports\ExportData;

/**
 * 全病历质控
 *
 * Class CaseQualityController
 * @package App\Http\Controllers\Api
 * @group case-quality
 */
class CaseQualityController extends Controller
{

    /**
     * analysis
     * /api/case-quality/analysis
     * 质量分析
     * @group case-quality
     * @bodyParam start_time string  开始时间  日期字符串格式
     * @bodyParam end_time string  结束时间  日期字符串格式
     *
     * @response {
     *  "code":200,
     *    "msg":"结果",
     *  "data":{
     *       "case_total":"病案数量",
     *       "defect_case_total":"缺陷病案数",
     *  },
     * "time":123787842
     * }
     */
    public function analysis(Request $request)
    {
        $queryCond = $this->commonQueryCond($request);

        // 病例数量
        $caseTotal = CaseQualityService::getCaseTotalByEs($queryCond);

        // 缺陷病案数
        $defectCaseTotal = CaseQualityService::getDefectCaseTotal($queryCond);

        $data['case_total'] = $caseTotal ?? 0;
        $data['defect_case_total'] = $defectCaseTotal ?? 0;

        DebugItemsService::getInstance()->calcDebugData($queryCond->debugis, $data);
        return ToolsService::jsonSuccess($data);
    }

    /**
     * ranking_department
     * /api/case-quality/ranking_department
     * 科室排名 前10条
     * @group case-quality
     * @bodyParam start_time string  开始时间  日期字符串格式
     * @bodyParam end_time string  结束时间  日期字符串格式
     *
     * @response {
     *  "code":200,
     *    "msg":"结果",
     *  "data": {
     *      "list":[{
     *          "name":"科室名称",
     *          "total_medical":"病案数",
     *          "total_error_medical":"缺陷病案数",
     *      }]
     *  },
     * "time":123787842
     * }
     */
    public function rankingDepartment(Request $request)
    {
        $queryCond = $this->commonQueryCond($request);

        $data = ['list' => [], 'count' => 0];
        // 总病例总数
        $caseTotal = CaseQualityService::getCaseTotalByEs($queryCond);

        $departmentCases = CaseQualityService::getDepartmentCases($queryCond);
        $departmentDefectCases = CaseQualityService::getDepartmentDefectCases($queryCond);

        DebugItemsService::getInstance()->putDebugItem('department_data', [
            '$caseTotal' => $caseTotal,
            '$departmentCases' => $departmentCases,
            '$departmentDefectCases' => $departmentDefectCases,
        ], 'data');

        $collects = [];

        foreach ($departmentCases as $case) {
            $name = $case['key'];
            $collects[$name]['name'] = $name;
            $collects[$name]['total_medical'] = $case['doc_count'];
            $collects[$name]['total_error_medical'] = 0;
        }

        $departmentDefectCases = array_column($departmentDefectCases, 'doc_count', 'key');
        foreach ($collects as $key => &$v) {
            $v['total_error_medical'] = empty($departmentDefectCases[$key]) ? 0 : $departmentDefectCases[$key];
        }

        DebugItemsService::getInstance()->putDebugItem('merge', $collects, 'data:');

        if (!empty($collects)) {
            // 缺陷病案数/总病案数    数值小的在前
            $collects = collect($collects)->sortBy(function ($item, $key) {
                return $item['total_error_medical'];
            })->values()->take(10)->all();
            $collects = array_values($collects);

            $data = ['list' => $collects, 'count' => count($collects)];
        }


        DebugItemsService::getInstance()->calcDebugData($queryCond->debugis, $data);
        return ToolsService::jsonSuccess($data);
    }

    /**
     * defect_issues
     * /api/case-quality/defect_issues
     * 缺陷问题列表
     * @group case-quality
     * @bodyParam start_time string  开始时间  日期字符串格式
     * @bodyParam end_time string  结束时间  日期字符串格式
     *
     * @response {
     *  "code":200,
     *    "msg":"结果",
     *  "data": {
     *      "list":[{
     *          "id":"序号",
     *          "desc":"缺陷描述",
     *          "field":"缺陷字段",
     *          "level":"缺陷分级",
     *          "total_num":"缺陷数量",
     *      }]
     *  },
     * "time":123787842
     * }
     */
    public function defectIssues(Request $request)
    {
        $totalStart = microtime(true);
        
        $depIds = UserService::getCurrentUserDep($request);
        if(empty($depIds)){
            return ToolsService::jsonSuccess(['count'=>0, 'list'=>[]]);
        }
        $queryCond = $this->commonQueryCond($request);
        
        // ============ 步骤1：使用原生SQL强制JOIN顺序 ============
        $step1Start = microtime(true);
        //Log::info('步骤1开始：查询缺陷统计（优化JOIN顺序）');
        
        // 使用 STRAIGHT_JOIN 强制从 patient_info 开始
        $sql = "
            SELECT case_quality.rule_id, COUNT(1) as total_num
            FROM patient_info
            STRAIGHT_JOIN case_quality ON case_quality.JZHM = patient_info.MED_REC_ID
                AND case_quality.is_correction = 0
                AND case_quality.is_appeal = 0
                AND case_quality.is_ignore = 0
            STRAIGHT_JOIN ZY_BRRY ON ZY_BRRY.ZYH = case_quality.JZHM
        ";
        
        $bindings = [];
        $where = [];
        
        // patient_info 条件
        $where[] = "patient_info.in_hospital = 2";
        $where[] = "patient_info.score IS NOT NULL";
        
        if ($queryCond->start_time && $queryCond->end_time) {
            $where[] = "patient_info.AAC01 >= ?";
            $where[] = "patient_info.AAC01 <= ?";
            $bindings[] = $queryCond->start_time . ' 00:00:00';
            $bindings[] = $queryCond->end_time . ' 00:00:00';
        }
        
        if ($queryCond->department) {
            $placeholders = implode(',', array_fill(0, count($queryCond->department), '?'));
            $where[] = "patient_info.AAC02C IN ($placeholders)";
            $bindings = array_merge($bindings, $queryCond->department);
        }
        
        if ($queryCond->AAA28) {
            $where[] = "patient_info.AAA28 = ?";
            $bindings[] = $queryCond->AAA28;
        }
        
        // ZY_BRRY 条件
        if (is_array($depIds) && !empty($depIds)) {
            $placeholders = implode(',', array_fill(0, count($depIds), '?'));
            $where[] = "ZY_BRRY.BRKS IN ($placeholders)";
            $bindings = array_merge($bindings, $depIds);
        }
        
        if (!empty($where)) {
            $sql .= " WHERE " . implode(' AND ', $where);
        }
        
        $sql .= " GROUP BY case_quality.rule_id ORDER BY total_num DESC";
        
        //Log::info('步骤1 SQL', ['sql' => $sql, 'bindings_count' => count($bindings)]);
        
        $statsRaw = DB::select($sql, $bindings);
        $stats = collect($statsRaw)->keyBy('rule_id');
        
        $step1End = microtime(true);
        /* Log::info('步骤1完成：查询缺陷统计', [
            'duration' => round(($step1End - $step1Start) * 1000, 2) . 'ms',
            'count' => $stats->count()
        ]); */
        
        if ($stats->isEmpty()) {
            return ToolsService::jsonSuccess(['count'=>0, 'list'=>[]]);
        }
        
        // ============ 步骤2：查询规则信息 ============
        $step2Start = microtime(true);
        //Log::info('步骤2开始：查询规则信息');
        
        $ruleIds = $stats->keys()->toArray();
        
        // 区分普通规则和设置规则
        $normalRuleIds = array_filter($ruleIds, fn($id) => $id < 1000000);
        $settingRuleIds = array_map(fn($id) => $id - 1000000, 
                                    array_filter($ruleIds, fn($id) => $id >= 1000000));
        
        $rules = collect();
        
        // 查询 case_rule
        if (!empty($normalRuleIds)) {
            $caseRules = DB::table('case_rule')
                ->select('id', 'category', 'notice')
                ->whereIn('id', $normalRuleIds)
                ->where('status', 1)
                ->when($queryCond->type, function($query) use ($queryCond) {
                    return $query->where('type', $queryCond->type);
                })
                ->when($queryCond->case_title, function($query) use ($queryCond) {
                    return $query->whereIn('category', $queryCond->case_title);
                })
                ->when($queryCond->rule_id, function($query) use ($queryCond) {
                    return $query->whereIn('notice', $queryCond->rule_id);
                })
                ->get()
                ->keyBy('id');
            $rules = $rules->merge($caseRules);
        }
        
        // 查询 rule_setting
        if (!empty($settingRuleIds)) {
            $settingRules = DB::table('rule_setting')
                ->selectRaw('id+1000000 as id, case_type as category, description as notice')
                ->whereIn('id', $settingRuleIds)
                ->where('status', 1)
                ->when($queryCond->type, function($query) use ($queryCond) {
                    return $query->where('type', $queryCond->type);
                })
                ->when($queryCond->case_title, function($query) use ($queryCond) {
                    return $query->whereIn('case_type', $queryCond->case_title);
                })
                ->when($queryCond->rule_id, function($query) use ($queryCond) {
                    return $query->whereIn('description', $queryCond->rule_id);
                })
                ->get()
                ->keyBy('id');
            $rules = $rules->merge($settingRules);
        }
        
        $step2End = microtime(true);
        /* Log::info('步骤2完成：查询规则信息', [
            'duration' => round(($step2End - $step2Start) * 1000, 2) . 'ms',
            'total_rules' => $rules->count()
        ]); */
        
        // ============ 步骤3：合并结果 ============
        $step3Start = microtime(true);
        
        $list = [];
        foreach ($stats as $ruleId => $stat) {
            if (isset($rules[$ruleId])) {
                $rule = $rules[$ruleId];
                $list[] = [
                    'key' => $ruleId,
                    'total_num' => (int)$stat->total_num,
                    'field' => $rule->category,
                    'desc' => $rule->notice,
                ];
            }
        }
        
        // 计算比例
        $scoreTotal = array_sum(array_column($list, 'total_num'));
        foreach ($list as &$v) {
            $v["proportion"] = $scoreTotal > 0 ? round($v["total_num"] / $scoreTotal * 100, 2).'%' : '0%';
        }
        
        $step3End = microtime(true);
        
        $totalEnd = microtime(true);
        /* Log::info('defectIssues 总耗时', [
            'total_duration' => round(($totalEnd - $totalStart) * 1000, 2) . 'ms',
            'breakdown' => [
                '步骤1-统计查询' => round(($step1End - $step1Start) * 1000, 2) . 'ms',
                '步骤2-规则查询' => round(($step2End - $step2Start) * 1000, 2) . 'ms',
                '步骤3-合并处理' => round(($step3End - $step3Start) * 1000, 2) . 'ms',
            ]
        ]); */
        
        return ToolsService::jsonSuccess(['count' => count($list), 'list' => $list]);
    }

    public function commonQueryCond(Request $request)
    {
        $start_time = $request->post("startTime");//日期字符串格式
        $end_time = $request->post("endTime");
        $department = $request->post("KS_CODE");
        $AAA28 = $request->post("AAA28");
        $type = $request->post("type");
        $debugis = $request->post("debugis", 0);
        if (empty($start_time)) {
            $start_time = date('Y-01-01');
        } else {
            $start_time = date('Y-m-d', strtotime($start_time));
        }
        if (empty($end_time)) {
            $end_time = date('Y-12-31');
        } else {
            $end_time = date('Y-m-d', strtotime($end_time));
        }

        $obj = new \stdClass();

        $obj->AAA28 = $AAA28;
        $obj->start_time = $start_time;
        $obj->end_time = $end_time;
        $obj->debugis = $debugis;
        $obj->department = $department;
        $obj->type = $type;
        $obj->rule_id = 0;
        $obj->case_title = [];
        $case_title = $request->post("case_title", 0);
        if($case_title) {
            $obj->case_title = explode(',', $case_title);
        }

        $case_notice = $request->post("case_notice", 0);
        if($case_notice) {
            $obj->rule_id = explode(',', $case_notice);
        }

        return $obj;
    }


    /**
     * 返回数组指定键值组
     */
    private function keyGetval($arr, $key)
    {
        $arrs = [];
        foreach ($arr as $v) {
            $arrs[] = $v[$key];
        }
        return $arrs;
    }

}
