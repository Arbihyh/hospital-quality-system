<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Model\Department;
use App\Model\RuleSetting;
use App\Model\RuleSettingDetail;
use App\Model\RuleWordMap;
use App\Model\TableDict;
use App\Services\CaseService;
use App\Services\ToolsService;
use Doctrine\Inflector\Rules\Ruleset;
use Illuminate\Http\Request;
use App\Model\RuleFormula;
use App\Model\RuleSettingOther;
use App\Model\TableDictSY;
use Illuminate\Support\Facades\DB;

class QualityRule extends Controller
{
    /**
     * @param Request $request
     * @return array
     * 添加规则信息
     */
    public function addDict(Request $request)
    {
        $id = intval($request->post('id'));
        $table = $request->post('table');
        $tableField = $request->post('table_field');
        $field = $request->post('field');
        $fieldName = $request->post('field_name');
        $remark = $request->post('remark');
        if (!$fieldName) {
            return ToolsService::returnData(4001, [], '参数不能为空');
        }

        $type = 1; // 表
        $parentField = $table ?: 0;
        if ($parentField) {
            $type = 2; // 字段
            $parentField = $tableField ?: 0;
            // 如果选择了字段则代表要在字段下面添加字典
            if ($parentField) {
                $type = 3;
            } else {
                // 如果没有选择字段，则表示要在表下面添加字段
                $parentField = $table;
            }
        }

        if (empty($id)) {
            // 判断数据是否重复添加
            $dict = TableDict::query()
                ->where('parent_field', '=', $parentField)
                ->where('field', '=', $field)
                ->where('field_name', '=', $fieldName)
                ->get()->toArray();
            if (!empty($dict[0])) {
                return ToolsService::returnAdmin(4001, [], '数据已存在，不能重复添加');
            }
        }

        $msg = '';
        try {
            TableDict::query()->insert([
                'parent_field' => $parentField,
                'field' => $field,
                'field_name' => $fieldName,
                'type' => $type,
                'remark' => $remark ?? "",
            ]);
            $code = 0;
        } catch (\Exception $e) {
            $code = 4001;
            $msg = $e->getMessage();
        }
        return ToolsService::returnAdmin($code, true, $msg);
    }

    /**
     * @param Request $request
     * @return array
     * 修改字段
     */
    public function editField(Request $request)
    {
        $id = intval($request->post('id'));
        $fieldName = $request->post('field_name');
        $remark = $request->post('remark');
        $status = $request->post('status');
        if (!$fieldName || !$id) {
            return ToolsService::returnData(4001, [], '参数不能为空');
        }

        $msg = '';
        try {
            TableDict::query()->where(['id' => $id])->update([
                'field_name' => $fieldName,
                'remark' => $remark,
                'status' => $status,
            ]);
            $code = 0;
        } catch (\Exception $e) {
            $code = 4001;
            $msg = $e->getMessage();
        }
        return ToolsService::returnAdmin($code, true, $msg);
    }

    /**
     * @param Request $request
     * @return array
     * 修改字段字典
     */
    public function editFieldDict(Request $request)
    {
        $id = intval($request->post('id'));
        $field = $request->post('field');
        $fieldName = $request->post('field_name');
        $remark = $request->post('remark');
        $status = $request->post('status');
        if (!$fieldName || !$id || !$field) {
            return ToolsService::returnData(4001, [], '参数不能为空');
        }

        $msg = '';
        try {
            TableDict::query()->where(['id' => $id])->update([
                'field' => $field,
                'field_name' => $fieldName,
                'remark' => $remark,
                'status' => $status,
            ]);
            $code = 0;
        } catch (\Exception $e) {
            $code = 4001;
            $msg = $e->getMessage();
        }
        return ToolsService::returnAdmin($code, true, $msg);
    }

    /**
     * @param Request $request
     * @param CaseDict $caseDict
     * @return array
     * 获取规则列表
     */
    //    public function getDict()
    public function getDict(Request $request)
    {
        $table = $request->post('table', '');
        $field = $request->post('field', '');
        $field_name = $request->post('field_name', '');
        $dict = $request->post('dict', '');
        $page = $request->post('page', 1);
        $pageSize = $request->post('page_size', 20);
        try {
            $query = TableDict::query()->where('parent_field', '=', 0)->where('status', '=', 1);
            if (!empty($table)) {
                $query = $query->where('id', '=', $table);
            }
            $parentField = $query->get()->toArray();
            $tableList = array_column($parentField, null, 'id');

            // 根据字典查询
            $fieldIds = [];
            if (!empty($dict)) {
                $dictRes = TableDict::query()->where('type', '=', 3)->where('field_name', '=', $dict)->get()->toArray();
                $fieldIds = array_column($dictRes, 'parent_field');
            }

            $obj = TableDict::query()->whereIn('parent_field', array_keys($tableList));
            if (!empty($fieldIds)) {
                $obj = $obj->whereIn('id', $fieldIds);
            }
            if (!empty($field)) {
                $obj = $obj->where('field', 'like', '%' . $field . '%');
            }
            if (!empty($field_name)) {
                $obj = $obj->where('field_name', 'like', '%' . $field_name . '%');
            }
            $count = $obj->count();

            $pageStart = ($page - 1) * $pageSize;
            $data = $obj->offset($pageStart)->LIMIT($pageSize)->get()->toArray();


            foreach ($data as &$v) {
                $v['parent_fildname'] = $tableList[$v['parent_field']]['field_name'] ?? '';
                $v['parent_field'] = $tableList[$v['parent_field']]['field'] ?? '';
            }

            $code = 0;
        } catch (\Exception $e) {
            $code = 4001;
            $msg = $e->getMessage();
        }

        return ToolsService::returnAdmin($code, ['count' => $count, 'list' => $data], $msg ?? '');
    }

    public function getDataByField(Request $request)
    {
        $field = $request->get('field');
        $id = $request->get('id', 0);
        $field = empty($field) ? $id : $field;
        $field_name = $request->get('field_name');

        $query = TableDict::query()->where('parent_field', '=', $field)->where('status', '=', 1);
        if (!empty($field_name)) {
            $query = $query->where('field_name', '=', $field_name);
        }
        $res = $query->get()->toArray();
        foreach ($res as &$r) {
            $r['field'] = $r['field'] . '(' . $r['field_name'] . ')';
        }
        return ToolsService::returnAdmin(0, $res, $msg ?? '');
    }

    /**
     * @param Request $request
     * @param CaseService $caseService
     * @return array
     * 获取字典详情
     */
    public function getDictDetail(Request $request)
    {
        $id = $request->get('id');
        if (!$id) {
            return ToolsService::returnAdmin(4001, [], '请求的参数有误');
        }
        $res = TableDict::query()->where('id', '=', $id)->get()->toArray();
        if (!$res) {
            return ToolsService::returnAdmin(4001, [], '数据不存在');
        }

        return ToolsService::returnAdmin(0, $res[0], $msg ?? '');
    }

    /**
     * @param Request $request
     * @param CaseService $caseService
     * @return array
     * 获取字典详情
     */
    public function delDict(Request $request, CaseService $caseService)
    {
        $id = $request->post('id');
        if (!$id) {
            return ToolsService::returnAdmin(4001, [], '请求的参数有误');
        }
        $res = TableDict::query()->where('id', '=', $id)->get()->toArray();
        if (!$res) {
            return ToolsService::returnAdmin(4001, [], '数据不存在');
        }

        try {
            TableDict::query()->where('id', '=', $id)->delete();
            $msg = '删除成功';
            $code = 0;
        } catch (\Exception $e) {
            $code = 4001;
            $msg = $e->getMessage();
        }

        return ToolsService::returnAdmin($code, $res[0], $msg ?? '');
    }

    /**
     * @param Request $request
     * @return array
     * 修改字典状态
     */
    public function editDictStatus(Request $request)
    {
        $id = $request->post('id');
        $status = $request->post('status');
        if (!$id) {
            return ToolsService::returnAdmin(4001, [], '请求的参数有误');
        }
        $res = TableDict::query()->where('id', '=', $id)->get()->toArray();
        if (!$res) {
            return ToolsService::returnAdmin(4001, [], '数据不存在');
        }

        try {
            TableDict::query()->where('id', '=', $id)->update(['status' => $status]);
            $code = 0;
            $msg = '修改成功';
        } catch (\Exception $e) {
            $code = 4001;
            $msg = $e->getMessage();
        }

        return ToolsService::returnAdmin($code, $res[0], $msg ?? '');
    }

    /**
     * @param Request $request
     * @return array
     * 根据表名和字段名查询数据
     */
    public function getDictByType(Request $request)
    {
        //传过来的参数table是表名,field是字段名,根据这个查询并返回数据
        $table = $request->get('table');
        $field = $request->get('field');
        $res = DB::table($table)->select($field)->get()->toArray();
        return ToolsService::returnAdmin(0, $res, $msg ?? '');
    }

    /**
     * @return array
     * 质控项目的下拉
     */
    public function getSelectObjectValue(Request $request)
    {
        $rule_type = $request->get('rule_type', '');
        $keyword = $request->get('keyword', '');
        if (!empty($rule_type) && $rule_type == 2) {
            $query = TableDictSY::query()
                ->where('status', '=', 1)
                ->whereIn('type', [1, 2, 3, 4]);

        } else {
            // 获取所有type为1,2,3的数据
            $query = TableDict::query()
                ->where('status', '=', 1)
                ->whereIn('type', [1, 2, 3, 4]);
        }
        if ($keyword) {
            $query = $query->where("field_name", "like", "%{$keyword}%");
        }

        $query1 = clone $query;
        $query1 = $query1->where('sort', '!=', 0)->orderBy('sort', 'asc')->get(['id', 'parent_field', 'field', 'field_name', 'type'])->toArray();

        $query2 = clone $query;
        $query2 = $query2->where('sort', '=', 0)->orderBy('id', 'asc')->get(['id', 'parent_field', 'field', 'field_name', 'type'])->toArray();

        $res = array_merge($query1, $query2);
        
        // sort不为0的部分按照sort排序,sort为0的部分按照id排序
        // 上面已经完成排序：先查询sort!=0按sort排序，再查询sort=0按id排序，最后合并
        $return = array_column($res, null, 'id');

        $category_tree = array();
        foreach ($return as $key => $v) {
            if ($v['parent_field'] == 0) {
                // 一级目录
                $category_tree[] = &$return[$key];
            } else {
                if ($v['type'] == 2) {
                    // 二级目录
                    $return[$v['parent_field']]['child'][] = &$return[$key];
                } else if ($v['type'] == 3) {
                    // 三级目录,直接添加到parent_field对应的二级目录下
                    if (!isset($return[$v['parent_field']]['child'])) {
                        $return[$v['parent_field']]['child'] = [];
                    }
                    $return[$v['parent_field']]['child'][] = &$return[$key];
                } else if ($v['type'] == 4) {
                    // 三级目录,直接添加到parent_field对应的二级目录下
                    if (!isset($return[$v['parent_field']]['child'])) {
                        $return[$v['parent_field']]['child'] = [];
                    }
                    $return[$v['parent_field']]['child'][] = &$return[$key];
                }
            }
        }

        return ToolsService::returnAdmin(0, $category_tree, $msg ?? '');
    }

    /**
     * @return array
     * 质控科室的下拉
     */
    public function getSelectDepartmentValue()
    {
        $res = Department::query()->get(['dep_id', 'dep_name'])->toArray();
        return ToolsService::returnAdmin(0, $res, $msg ?? '');
    }

    /**
     * 添加规则
     */
    public function addRule(Request $request)
    {
        $id = intval($request->post('id'));
        $caseType = $request->post('case_type', '');
        $changjing = $request->post('changjing', '');
        $department = $request->post('department', '');
        $object = $request->post('object', '');
        $type = $request->post('type', '');
        $ruleType = $request->post('rule_type', '');
        $isNot = $request->post('is_not', 0);
        $description = $request->post('description', '');
        $score = $request->post('score', 0);
        $errorLevel = $request->post('error_level', 0);
        $status = $request->post('status', '');
        $rule = $request->post('rule');

        if (!is_array($department)) {
            return ToolsService::returnAdmin(1, '', '科室参数需要是数组');
        }
        if (!is_array($object)) {
            return ToolsService::returnAdmin(1, '', '场景参数需要是数组');
        }

        $msg = '';
        $data = [
            'case_type' => $caseType ?? '',
            'department' => json_encode($department),
            'object' => implode(',', $object),
            'changjing' => implode(',', $changjing),
            'type' => $type ?? '',
            'rule_type' => $ruleType ?? '',
            'is_not' => $isNot ?? 0,
            'description' => $description ?? '',
            'score' => $score ?? 0,
            'error_level' => $errorLevel ?? 0,
            'status' => $status ?? 1,
        ];
        if (empty($id)) {
            $ruleId = RuleSetting::query()->insertGetId($data);
        } else {
            RuleSetting::query()->where(['id' => $id])->update($data);
            $ruleId = $id;
        }


        $ruleDetail = [];
        foreach ($rule as $r) {
            $ruleDetail[] = [
                'rule_id' => $ruleId,
                'condition_type' => $r['condition_type'] ?? 0,
                'condition_relation' => $r['condition_relation'] ?? 0,
                'is_pre_condition' => $r['is_pre_condition'] ?? 0,
                'condition_content' => !empty($r['condition_content']) ? json_encode($r['condition_content'], 256) : "",
                'pre_warning' => $r['pre_warning'] ?? 0,
                'pre_warning_time' => $r['pre_warning_time'] ?? 0,
                'time_judge' => $r['time_judge'] ?? 0,
                'time_judge_value' => $r['time_judge_value'] ?? "",
                'use_big_model' => $r['use_big_model'] ?? 0,
                'detail_status' => $r['detail_status'] ?? 2,
                'custom_basis' => !empty($r['custom_basis']) ? json_encode($r['custom_basis'], 256) : "",
                'custom_msg' => !empty($r['custom_msg']) ? json_encode($r['custom_msg'], 256) : "",
            ];
        }
        RuleSettingDetail::query()->where(['rule_id' => $ruleId])->delete();
        RuleSettingDetail::query()->insert($ruleDetail);
        $code = 0;
        return ToolsService::returnAdmin($code, true, $msg);
    }


    /**
     * @param Request $request
     * @param CaseDict $caseDict
     * @return array
     * 获取规则列表
     */
    public function getRuleList(Request $request)
    {
        $caseType = $request->get('case_type', '');
        $object = $request->get('object', '');
        $department = $request->get('department', []);
        $isNot = $request->get('is_not', '');
        $status = $request->get('status', '');
        $type = $request->get('type', '');
        $rule_type = $request->get('rule_type', '');
        $changjing = $request->get('changjing', '');
        $errorLevel = $request->get('error_level', '');
        $score = $request->get('score', '');
        $description = $request->get('description', '');
        $page = $request->get('page', 1);
        $pageSize = $request->get('page_size', 20);

        $obj = RuleSetting::query()->where('status', '!=', 3);
        if (!empty($fieldMap)) {
            $obj = $obj->whereIn('field', $fieldMap);
        }
        if (!empty($description)) {
            $obj = $obj->where('description', 'like', '%' . $description . '%');
        }
        if (!empty($score)) {
            $obj = $obj->where('score', '=', $score);
        }
        if (!empty($errorLevel)) {
            $obj = $obj->where('error_level', '=', $errorLevel);
        }
        if (!empty($caseType)) {
            $obj = $obj->where('case_type', '=', $caseType);
        }
        if (!empty($object)) {
            $obj = $obj->where('object', 'like', '%' . $object . '%');
        }
        if (count($department) > 0) {
            $departmentWhere = [];
            foreach ($department as $item) {
                $departmentWhere[] = "JSON_CONTAINS(department, '" . $item . "')";
            }
            $obj = $obj->whereRaw('(' . implode(' or ', $departmentWhere) . ')');
        }
        if (!empty($isNot)) {
            $obj = $obj->where('is_not', '=', $isNot);
        }
        if (!empty($status)) {
            $obj = $obj->where('status', '=', $status);
        }
        if (!empty($type)) {
            $obj = $obj->where('type', '=', $type);
        }
        if (!empty($changjing)) {
            $obj = $obj->where('changjing', '=', $changjing);
        }
        if (!empty($rule_type)) {
            if ($rule_type == 1) {
                $obj = $obj->where('rule_type', '=', "普通规则");
            } else if ($rule_type == 2) {
                $obj = $obj->where('rule_type', '=', "首页规则");
            }
        }
        $count = $obj->count();

        $pageStart = ($page - 1) * $pageSize;
        $data = $obj->offset($pageStart)->LIMIT($pageSize)->get()->toArray();

        $department = Department::query()->get(['dep_id', 'dep_name'])->toArray();
        $department = array_column($department, 'dep_name', 'dep_id');
        $dict = TableDict::query()->where('status', '=', 1)->whereIn('type', [1, 2])->get(['id', 'parent_field', 'field', 'field_name'])->toArray();
        $dict = array_column($dict, null, 'id');

        foreach ($data as $k => $v) {
            $departmentStr = [];
            $departmentArr = json_decode($v['department'], true);
            if ($rule_type == 1) {
                foreach ($departmentArr as $v1) {
                    $departmentStr[] = $department[$v1] ?? '';
                }
                $data[$k]['department'] = implode(',', $departmentStr);
            } else {
                $data[$k]['department'] = $departmentArr ? $departmentArr[0] : '';
            }
            $data[$k]['error_level'] = intval($data[$k]['error_level']);
            //                $data[$k]['object'] = $dict[$v['object']]['field_name'] ?? '';
        }

        $code = 0;
        return ToolsService::returnAdmin($code, ['count' => $count, 'list' => $data], $msg ?? '');
    }

    /**
     * @param Request $request
     * @return array
     * 获取规则详情
     */
    public function getRuleDetail(Request $request)
    {
        $id = $request->get('id');

        $ruleSetting = RuleSetting::query()->where('id', '=', $id)->get()->toArray();
        $ruleSetting = $ruleSetting[0];
        $ruleSettingDetail = RuleSettingDetail::query()->where('rule_id', '=', $id)->get()->toArray();
        $ruleSetting['department'] = json_decode($ruleSetting['department'], 256);
        $ruleSetting['error_level'] = intval($ruleSetting['error_level']);
        foreach ($ruleSettingDetail as &$d) {
            $d['condition_content'] = json_decode($d['condition_content'], true);
            if (!empty($d['custom_basis'])) {
                $d['custom_basis'] = json_decode($d['custom_basis'], true);
            }
            if (!empty($d['custom_msg'])) {
                $d['custom_msg'] = json_decode($d['custom_msg'], true);
            }
        }

        return ToolsService::returnAdmin(0, ['rule' => $ruleSetting, 'rule_list' => $ruleSettingDetail], $msg ?? '');
    }

    /**
     * @param Request $request
     * @return array
     * 添加规则信息
     */
    public function addWordMap(Request $request)
    {
        $name = $request->post('name');
        $keywords = $request->post('keywords');
        if (!$name || !$keywords) {
            return ToolsService::returnData(4001, [], '参数不能为空');
        }

        $msg = '';
        try {
            RuleWordMap::query()->insert([
                'name' => $name,
                'keyword' => implode(',', json_decode($keywords)),
            ]);
            $code = 0;
        } catch (\Exception $e) {
            $code = 4001;
            $msg = $e->getMessage();
        }
        return ToolsService::returnAdmin($code, true, $msg);
    }

    /**
     * @param Request $request
     * @return array
     * 添加规则信息
     */
    public function editRuleStatus(Request $request)
    {
        $id = $request->post('id');
        $status = $request->post('status');
        if (!$id || !$status) {
            return ToolsService::returnData(4001, [], '参数不能为空');
        }

        $msg = '';
        try {
            RuleSetting::query()->where('id', '=', $id)->update([
                'status' => $status,
            ]);
            $code = 0;
        } catch (\Exception $e) {
            $code = 4001;
            $msg = $e->getMessage();
        }
        return ToolsService::returnAdmin($code, true, $msg);
    }

    /**
     * @param Request $request
     * @return array
     * 修改字段
     */
    public function editWordMap(Request $request)
    {
        $id = intval($request->post('id'));
        $name = $request->post('name');
        $keywords = $request->post('keywords');
        $BZMC = $request->post('BZMC') ?? null;

        if (!$name || !$keywords) {
            return ToolsService::returnData(4001, [], '参数不能为空');
        }

        // 处理 keywords 字符串
        // 如果 keywords 已经是字符串，直接使用
        if (is_string($keywords)) {
            $keywordsStr = $keywords;
        }
        // 如果是数组，则进行 implode
        else if (is_array($keywords)) {
            $keywordsStr = implode(',', $keywords);
        }
        // 如果是 JSON 字符串，先解码再 implode
        else {
            try {
                $keywordsArray = json_decode($keywords, true);
                $keywordsStr = is_array($keywordsArray) ? implode(',', $keywordsArray) : $keywords;
            } catch (\Exception $e) {
                $keywordsStr = $keywords;
            }
        }

        $msg = '';
        try {
            RuleWordMap::query()->where(['id' => $id])->update([
                'name' => $name,
                'keyword' => $keywordsStr,
                'BZMC' => $BZMC,
            ]);
            $code = 0;
        } catch (\Exception $e) {
            $code = 4001;
            $msg = $e->getMessage();
        }
        return ToolsService::returnAdmin($code, true, $msg);
    }


    /**
     * @param Request $request
     * @param CaseDict $caseDict
     * @return array
     * 获取规则列表
     */
    public function getWordMap(Request $request)
    {
        $name = $request->post('name', '');
        $keyword = $request->post('keyword', '');
        $page = $request->post('page', 1);
        $pageSize = $request->post('page_size', 10);
        $id = $request->post('id', '');

        try {
            $obj = RuleWordMap::query();
            if (!empty($id)) {
                $obj = $obj->where('id', '=', $id);
            }
            if (!empty($name)) {
                $obj = $obj->where('name', 'like', '%' . $name . '%');
            }
            if (!empty($keyword)) {
                $obj = $obj->where('keyword', 'like', '%' . $keyword . '%');
            }
            $count = $obj->count();

            $pageStart = ($page - 1) * $pageSize;
            $data = $obj->offset($pageStart)->LIMIT($pageSize)->get()->toArray();


            foreach ($data as &$v) {
                $v['keywords'] = explode(',', $v['keyword']);
            }

            $code = 0;
        } catch (\Exception $e) {
            $code = 4001;
            $msg = $e->getMessage();
        }

        return ToolsService::returnAdmin($code, ['count' => $count, 'list' => $data], $msg ?? '');
    }

    /**
     * @param Request $request
     * @param CaseDict $caseDict
     * @return array
     * 获取规则列表
     */
    public function getAllWordMap(Request $request)
    {
        $name = $request->post('name', '');
        try {
            $obj = RuleWordMap::query();
            if (!empty($name)) {
                $obj = $obj->where('name', 'like', '%' . $name . '%');
            }
            $data = $obj->get()->toArray();

            foreach ($data as &$v) {
                $v['keywords'] = explode(',', $v['keyword']);
            }

            $code = 0;
        } catch (\Exception $e) {
            $code = 4001;
            $msg = $e->getMessage();
        }

        return ToolsService::returnAdmin($code, $data, $msg ?? '');
    }

    /**
     * @param Request $request
     * @return array
     * 删除字段
     */
    public function delWordMap(Request $request)
    {
        $id = intval($request->post('id'));
        if (!$id) {
            return ToolsService::returnData(4001, [], '参数不能为空');
        }

        $msg = '';
        try {
            RuleWordMap::query()->where(['id' => $id])->delete();
            $code = 0;
        } catch (\Exception $e) {
            $code = 4001;
            $msg = $e->getMessage();
        }
        return ToolsService::returnAdmin($code, true, $msg);
    }

    /**
     * @param Request $request
     * @return array
     * 删除规则
     */
    public function delRule(Request $request)
    {
        $id = intval($request->post('id'));
        if (!$id) {
            return ToolsService::returnData(4001, [], '参数不能为空');
        }

        $msg = '';
        try {
            //修改逻辑,删除规则时,将规则状态改为3,表示已删除
            RuleSetting::query()->where(['id' => $id])->update(['status' => 3]);
            //RuleSettingDetail::query()->where(['rule_id' => $id])->delete();
            $code = 0;
        } catch (\Exception $e) {
            $code = 4001;
            $msg = $e->getMessage();
        }
        return ToolsService::returnAdmin($code, true, $msg);
    }

    /**
     * 获取规则公式列表
     * @return array
     */
    public function getSelectFormula(Request $request)
    {
        try {
            //添加条件,获取传入参数lx,根据lx返回对应的公式
            $lx = $request->get('lx', '');
            $formulas = RuleFormula::query()->where('lx', '=', $lx)->get(['id', 'formula'])->toArray();
            $code = 0;
        } catch (\Exception $e) {
            $formulas = [];
            $code = 4001;
            $msg = $e->getMessage();
        }

        return ToolsService::returnAdmin($code, $formulas, $msg ?? '');
    }

    //新建方法,从表rule_setting_other中获取病历类型,质控类型,质控场景的下拉数据
    public function getRuleSettingOther(Request $request)
    {
        //type:1病历类型,2质控类型,3质控场景
        $type = $request->get('type', '');
        $issz = $request->get('issz', 0);
        $data = RuleSettingOther::query()->where('type', '=', $type)->get(['id', 'name'])->toArray();

        if($type == 1 && $issz == 1){
            $data = TableDictSY::query()->where('parent_field', '!=', 0)->get(['id', 'field_name as name'])->toArray();
        }
        return ToolsService::returnAdmin(0, $data, $msg ?? '');
    }

}
