<?php

namespace App\Console\Commands;

use App\Http\Controllers\Admin\QualityRule;
use App\Http\Controllers\Api\CaseHistory\Terminal\IndexController;
use App\Model\CaseQuality;
use App\Model\CaseRule;
use App\Model\Department;
use App\Model\EMR_BL_BL01;
use App\Model\MainDiagnosis;
use App\Model\MainOperation;
use App\Model\PatientDoctorInfo;
use App\Model\PatientInfo;
use App\Model\PatientInfoDiagnosisV2;
use App\Model\PatientInfoOperationV2;
use App\Model\PatientInfoV2;
use App\Model\RuleSetting;
use App\Model\Staff;
use App\Services\OperationService;
use App\Services\RadioService;
use App\Services\ToolsService;
use App\Services\UserService;
use Illuminate\Console\Command;
use App\Services\CaseService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use mysql_xdevapi\Exception;
use Pheanstalk\Pheanstalk;
use function GuzzleHttp\json_encode;
use App\Services\BcService;

class Test1 extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     * php artisan command:case
     */
    protected $signature = 'test1';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command 定时生成执行相关诊断信息的统计信息';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     *
     */
    public function handle()
    {
        $str = "i63.4444";
        $str = preg_match('/i([6-6][3-4]).*/', $str, $matches);
        var_dump($matches);
        exit;
        $addUser = \App\Model\User::query()->pluck('realname')->toArray();
        var_dump($addUser);
        exit;
        DB::enableQueryLog();

        // 获取查询日志
        $queries = DB::getQueryLog();
        $lastQuery = end($queries);
        var_dump("最后一条 SQL 语句: ". $lastQuery['query']. "\n");
        var_dump(date("Y-m-d", strtotime("20250101")));



        $depIds = UserService::getCurrentUserDep($request);
        if (empty($depIds)) {
            return ToolsService::jsonSuccess(['count' => 0, 'data' => []]);
        }
        //处理where条件
        $query = PatientInfo::query()
            ->leftJoin('ZY_BRRY', 'ZY_BRRY.ZYH', '=', 'patient_info.MED_REC_ID')
            ->leftJoin('patient_info_v2', 'patient_info_v2.ZYH', '=', 'patient_info.MED_REC_ID')
            ->when(is_array($depIds), function ($query) use ($depIds) {
                return $query->whereIn('ZY_BRRY.BRKS', $depIds);
            })
            ->whereNotNull('patient_info.MED_REC_ID')
            ->where("patient_info.in_hospital", 2);
        //缺陷数量
        $is_qx = $request->post('is_qx', 0);
        if ($is_qx == 1) {
            $query->where("patient_info.score", "<", 100);
        }

        //住院天数(起始天数)
        $startDay = $request->post('endDay1');
        if (is_numeric($startDay)) $query->where('patient_info.AAC04', '>=', $startDay);
        //住院天数(结束天数)
        $endDay = $request->post('endDay2');
        if (is_numeric($endDay)) $query->where('patient_info.AAC04', '<=', $endDay);

        //病案质量
        $lb_level = $request->post('lb_level');
        $score_lv = config("dictionaries.AED01C");
        if (!empty($lb_level)) $query->where('patient_info.score_lv', $score_lv[$lb_level]);

        //住院号
        $AAA28 = $request->post('AAA28');
        if (!empty($AAA28)) $query->where('patient_info.AAA28', $AAA28);

        //院区
        $YQ_CODE = $request->post('YQ_CODE');
        if (!empty($YQ_CODE)) {
            $YQ_CODE = explode(",", $YQ_CODE);
            $YQ_CODE = array_filter($YQ_CODE);
            if ($YQ_CODE) {
                $query->whereIn('patient_info.YQ_CODE', $YQ_CODE);
            }
        }
        //科室
        $KS_CODE = $request->post("KS_CODE");
        if (!empty($KS_CODE)) {
            $KS_CODE = explode(",", $KS_CODE);
            $KS_CODE = array_filter($KS_CODE);
            if ($KS_CODE) {
                $query->whereIn("ZY_BRRY.BRKS", $KS_CODE);
            }
        }
        //病区
        $BQ_CODE = $request->post('BQ_CODE');
        if (!empty($BQ_CODE)) {
            $BQ_CODE = explode(",", $BQ_CODE);
            $BQ_CODE = array_filter($BQ_CODE);
            if ($BQ_CODE) {
                $query->whereIn("patient_info.BQ_CODE", $BQ_CODE);
            }
        }

        //出院时间（起始时间）
        $start_time = $request->post('start_time');
        $start_time = $start_time ? date("Y-m-d 00:00:00", strtotime($start_time)) : "";
        if (!empty($start_time)) $query->where('patient_info.AAC01', '>=', $start_time);
        //出院时间（结束时间）
        $end_time = $request->post('end_time');
        $end_time = $end_time ? date("Y-m-d 00:00:00", strtotime($end_time)) : "";
        if (!empty($start_time)) $query->where('patient_info.AAC01', '<=', $end_time);


        //离院方式
        $AEM01C = $request->post('AEM01C');
        $query->when($AEM01C, function ($query) use ($AEM01C){
            $query->where('patient_info_v2.AEM01C', $AEM01C)
                ->orWhere('patient_info.AEM01C', $AEM01C);
        });

        //问题描述
        // 规则ID
        $ruleId = $request->post('rule_id');
        if (!empty($ruleId)) $query->where('case_quality.rule_id', $ruleId);

        //规则类型
        $rule_type = $request->post('rule_type');
        if ($rule_type) {
            $type_ids = [];
            $result = CaseRule::query()->where('type', $rule_type)->get(['id'])->toArray();
            if ($result) {
                $type_ids = array_column($result, 'id');
            }

            $ruleSetting = RuleSetting::query()->where('type', $rule_type)->get(['id'])->toArray();
            if ($ruleSetting) {
                $ruleSetting = array_column($ruleSetting, 'id');
                $ruleSetting = array_map(function ($v) {
                    return $v + 1000000;
                }, $ruleSetting);
                $type_ids = array_merge($type_ids, $ruleSetting);
            }

            $query->whereIn('case_quality.rule_id', $type_ids);
        }

        //分页
        $page = $request->post('page', 1);
        $pageSize = $request->post('size', 10);

        //获取数据
        $table = $query->orderBy("patient_info.AAC01", "desc")->paginate($pageSize, ['patient_info.AAB01', 'patient_info.MED_REC_ID', 'patient_info.id', 'patient_info.AAC02C', 'patient_info.AAA28', 'patient_info.AAC01', 'patient_info.AAA01', 'patient_info.score', 'patient_info.AAC04', 'patient_info_v2.AEM01C as AEM01C_v2', 'patient_info.AEM01C', 'patient_info.AAB01', 'ZY_BRRY.BRKS', 'ZY_BRRY.ZYCS', 'ZY_BRRY.ZZYSMC', 'ZY_BRRY.ZZYSDM'], 'page', $page)->toArray();

        $depArray = Department::query()->pluck('dep_name', 'dep_id')->toArray();
        $AEM01C = config('dictionaries.AEM01C');
        $ZYH = array_column($table['data'], "MED_REC_ID");
        $ptv2 = PatientInfoV2::query()->whereIn("ZYH", $ZYH)->where("status", 0)->get(["AAC11N", "AAC04", "ZYH"])->toArray();
        $ptv2 = array_column($ptv2, NULL, "ZYH");

        $patientDoctorInfo = PatientDoctorInfo::query()->whereIn("AAA28", $ZYH)->get(["AAA28", "AEE03", "AEE03_CODE"])->toArray();
        $patientDoctorInfo = array_column($patientDoctorInfo, NULL, "AAA28");

        $mainDiagnosis = MainDiagnosis::query()->whereIn("AAA28", $ZYH)->pluck("ICD10_NAME", "AAA28");
        $mainOperation = MainOperation::query()->whereIn("AAA28", $ZYH)->pluck("ICD9_NAME", 'AAA28');
        $patientInfoDiagnosisV2 = PatientInfoDiagnosisV2::query()->whereIn("ZYH", $ZYH)->pluck("ICD10_NAME", "ZYH");
        $patientInfoOperationV2 = PatientInfoOperationV2::query()->whereIn("ZYH", $ZYH)->pluck("ICD9_NAME", 'ZYH');

        foreach ($table['data'] as $k => $v) {
            $v['ICD10_NAME'] = $mainDiagnosis[$v['MED_REC_ID']] ?? "";
            if(empty($v['ICD10_NAME'])){
                $v['ICD10_NAME'] = $patientInfoDiagnosisV2[$v['MED_REC_ID']] ?? "";
            }
            $v['ICD9_NAME'] = $mainOperation[$v['MED_REC_ID']] ?? "";
            if(empty($v['ICD9_NAME'])){
                $v['ICD9_NAME'] = $patientInfoOperationV2[$v['MED_REC_ID']] ?? "";
            }
            $v['AEE03'] = $patientDoctorInfo[$v['MED_REC_ID']]['AEE03'] ?? "";
            $v['AEE03_CODE'] = $patientDoctorInfo[$v['MED_REC_ID']]['AEE03_CODE'] ?? "";
            $v["AAC04"] = $v["ZYCS"] ?: $ptv2[$v["MED_REC_ID"]]["AAC04"] ?? "";
            $v['AAC11N'] = $depArray[$v['BRKS']] ?? $ptv2[$v["MED_REC_ID"]]["AAC11N"] ?? "";//出院科室
            $v['index'] = $k + 1;//序号
            $v['AEM01C_MC'] = $v['AEM01C'] && $AEM01C[$v['AEM01C']] ? $AEM01C[$v['AEM01C']] : ($v['AEM01C_v2'] && $AEM01C[$v['AEM01C_v2']] ? $AEM01C[$v['AEM01C_v2']] : "");
            $v['score_lv'] = PatientInfo::getBlZl($v['score']);//病历质量
            $v['AEE03'] = "{$v['ZZYSMC']}/{$v['ZZYSDM']}";

            $table['data'][$k] = $v;
        }

        $data = [];
        $data['count'] = $table['total'];
        $data['data'] = $table['data'];
        return ToolsService::returnData(200, $data);



    }

}
