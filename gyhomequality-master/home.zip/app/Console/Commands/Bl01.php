<?php

namespace App\Console\Commands;

use App\Model\EMR_BL_BL01;
use App\Model\EMR_BL_BLXG;
use Illuminate\Console\Command;

class Bl01 extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'laravel:bl01';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        ini_set('default_socket_timeout', 0);
        $star = '2022-01-01';
//        $between = ['2022-04-05 00:00:00','2022-04-05 23:59:59'];
//        $del = EMR_BL_BL01::query()->whereBetween('ZXSJ',$between)->pluck('BLBH');
//        EMR_BL_BL01::query()->whereIn('BLBH',$del)->delete();
//        EMR_BL_BLXG::query()->whereIn('BLBH',$del)->delete();
        while (true){
            echo $star."\n";
            $con = oci_connect('PORTAL55_EMR', 'emr#2023', '10.10.11.21:1521/ODS', 'UTF8');
            if (!$con) {
                $e = oci_error();
                print_r(htmlentities($e['message'])) . "\n";
                die;
            }
            //$sql = "SELECT * FROM (SELECT ROWNUM r,a.*,to_char(ZXSJ,'yyyy-mm-dd hh24:mi:ss') as ZJ,to_char(CJSJ,'yyyy-mm-dd hh24:mi:ss') as CJ,to_char(WCSJ,'yyyy-mm-dd hh24:mi:ss') as WJ FROM PORTAL55_EMR.V_JMGS_BASY_QBL a) WHERE ZXSJ BETWEEN TO_DATE('2022-12-01 00:00:00', 'yyyy-MM-dd HH24:mi:ss') AND TO_DATE('2022-12-01 00:00:00', 'yyyy-MM-dd HH24:mi:ss') AND r BETWEEN $start AND $end";
            $sql = "SELECT a.*,to_char(ZXSJ,'yyyy-mm-dd hh24:mi:ss') as ZJ,to_char(CJSJ,'yyyy-mm-dd hh24:mi:ss') as CJ,to_char(WCSJ,'yyyy-mm-dd hh24:mi:ss') as WJ,to_char(XGSJ,'yyyy-mm-dd hh24:mi:ss') as XJ FROM PORTAL55_EMR.V_JMGS_BASY_QBL a WHERE ZXSJ BETWEEN TO_DATE('".$star." 00:00:00', 'yyyy-MM-dd HH24:mi:ss') AND TO_DATE('".$star." 23:59:59', 'yyyy-MM-dd HH24:mi:ss')";
            $result = oci_parse($con, $sql);
            oci_execute($result,OCI_DEFAULT);
            $data = [];
            while ($row = oci_fetch_assoc($result)) {
                $data[] = $row;
            }
            if (empty($data)){
                break;
            }
            foreach ($data as $item){
                $result = [
                    'BLBH' => $item['BLBH'] ?? '',
                    'JZHM' => $item['ZYH'] ?? '',
                    'BRBH' => $item['BRBH'] ?? '',
                    'BLLX' => $item['BLLX'] ?? '',
                    'BLLB' => $item['BLLB'] ?? '',
                    'BLMC' => $item['BLMC'] ?? '',
                    'BLZM' => $item['BLZM'] ?? '',
                    'DLLB' => $item['DLLB'] ?? '',
                    'DLJ' => $item['DLJ'] ?? '',
                    'MBLB' => $item['MBLB'] ?? '',
                    'MBBH' => $item['MBBH'] ?? '',
                    'ZXSJ' => $item['ZJ'] ?? '',
                    'CJSJ' => $item['CJ'] ?? '',
                    'WCSJ' => $item['WJ'] ?? '',
                    'SXYS' => $item['SXYS'] ?? '',
                    'BRKS' => $item['BRKS'] ?? '',
                    'CJKS' => $item['CJKS'] ?? '',
                    'BLZT' => $item['BLZT'] ?? '',
                    'BRXM' => $item['BRXM'] ?? '',
                    'BRZD' => $item['BRZD'] ?? '',
                    'SSYS' => $item['SSYS'] ?? '',
                    'SYBZ' => $item['SYBZ'] ?? '',
                    'BZMBBH' => $item['BZMBBH'] ?? '',
                    'BLYM' => $item['BLYM'] ?? '',
                    'YMJL' => $item['YMJL'] ?? '',
                    'RYZDSJ' => $item['RYZDSJ'] ?? '',
                    'PTID' => $item['PTID'] ?? '',
                    'BLZSTJ' => $item['BLZSTJ'] ?? '',
                    'JGID' => $item['JGID'] ?? '',
                    'SQDH' => $item['SQDH'] ?? '',
                    'ZDMC' => $item['ZDMC'] ?? '',
                    'ZDLX' => $item['ZDLX'] ?? '',
                    'CXPX' => $item['CXPX'] ?? '',
                    'SBBZ' => $item['SBBZ'] ?? '',
                    'WZZT' => $item['WZZT'] ?? ''
                ];
                $text = $item['HJNR']->load();
                $item['HJNR']->free();
                $mde = mb_detect_encoding($text, array("ASCII",'UTF-8',"GB2312","GBK",'BIG5'));
                $str = '';
                if ($mde == 'UTF-8'){
                    $str = mb_convert_encoding($text,'utf-8',$mde);
                }
                $temp = [
                    'JLXH' => $item['JLXH'] ?? '',
                    'BLBH' => $item['BLBH'] ?? '',
                    'XGGH' => $item['XGGH'] ?? '',
                    'XGSJ' => $item['XJ'] ?? '',
                    'HJNR' => $str,
                ];
                EMR_BL_BLXG::query()->insert($temp);
                EMR_BL_BL01::query()->insert($result);
            }
            $star = date('Y-m-d',strtotime($star)+86400);
        }
        return 0;
    }
}
