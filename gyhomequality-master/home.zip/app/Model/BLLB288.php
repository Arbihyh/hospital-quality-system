<?php

namespace App\Model;

use DateTimeInterface;
use Illuminate\Database\Eloquent\Model;

class BLLB288 extends Model
{
    const FLAG_CYZD = '死亡信息';

    protected $table = 'bllb288';

    protected function serializeDate(DateTimeInterface $date)
    {
        return $date->format('Y-m-d H:i:s');
    }


}
