<?php


namespace App\Model;

use DateTimeInterface;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Cache;

class Department extends Model
{
    protected $table = 'department';
    protected function serializeDate(DateTimeInterface $date)
    {
        return $date->format('Y-m-d H:i:s');
    }

    public static function getDepartmentData($hospitalName='')
    {
        $hospital_name = !empty($hospitalName) ? $hospitalName : config('confAdmin.hospital_name');
        return Department::query()
            // ->where('hospital_name','=',$hospital_name)
//            ->where('flag','=',1)
            ->pluck('dep_name','dep_id')->toArray();
    }

    public static function getDepartmentList($hospitalName='')
    {
        $hospital_name = !empty($hospitalName) ? $hospitalName : config('confAdmin.hospital_name');
        return Department::query()
            // ->where('hospital_name','=',$hospital_name)
            ->where('type_id','=',2)
            ->get(['dep_id','dep_name'])->toArray();
    }

    public static function getOmrDepartmentData($hospitalName='')
    {
        $hospital_name = !empty($hospitalName) ? $hospitalName : config('confAdmin.hospital_name');
        return Department::query()
            ->where('hospital_name','=',$hospital_name)
            ->where('MZSY','=','Y')
            ->pluck('dep_name','dep_id')->toArray();
    }

    /**
     * 获取科室名称
     */
    public static function getDepartmentName($depId)
    {
        $table = Cache::get('departmentName');
        if (empty($table))
        {
            $table = self::query()->get(['dep_id','dep_name'])->keyBy('dep_id');
            Cache::put('departmentName',$table,60*60*24);
        }
        return  $table[$depId]['dep_name'] ?? '暂无数据';
    }

    /**
     * 获取院区/科室/病区
     */
    public static function getDepartmentOptions(int $type=1, int $level=1,array $parent_id=[])
    {
        $query = Department::query()->where('type_id',$type)->where('level_id',$level);
        if (!empty($parent_id) ) $query->whereIn('parent_id',$parent_id);
        $table =  $query->get(['dep_id as YQ_CODE','dep_name as YQ_NAME','dep_id as value','dep_name as label','dep_id','dep_name','id','level_id','type_id'])->toArray();

        if (!empty($table)){
            foreach ($table as $k=>$v){
                $child = self::getDepartmentOptions($v['type_id'],$v['level_id']+1,[$v['dep_id']]);
                if(!empty($child)){
                    $table[$k]['children'] = $child;
                }
            }
        }
        return $table;
    }

    /**
     * 更新部门的所有子集
     * @return void
     */
   public static function updateSubIds()
   {
       $table = self::query()->get(['id', 'parent_id','dep_id'])->toArray();
       foreach ($table as $v) {
           self::updateSubIdsRecursively($v['dep_id']);
       }
   }

    /**
     * 无限级递归方法,用于更新部门所有子集
     * @param $currentId
     * @param $visited
     * @return void
     */
   public static function updateSubIdsRecursively($currentDepId, $visited = [])
   {
       // 如果当前节点已经访问过，则跳过
       if (in_array($currentDepId, $visited)) return;
       $visited[] = $currentDepId;//记录已经访问过的节点

       // 获取子集
       $children = self::query()->where('parent_id', $currentDepId)->get(['id', 'parent_id','dep_id']);

       //开始递归
       $subIds = [$currentDepId]; //含自己
       foreach ($children as $v) {
           // 递归获取子节点的所有后代 ID
           $subIds = array_merge($subIds, self::updateSubIdsRecursively($v['dep_id'], $visited)
           );
       }

       //去重
       $subIds = array_unique($subIds);

       //更新
       self::query()->where('dep_id', $currentDepId)->update(['sub_ids' => implode(',', $subIds)]);

       return $subIds;
   }

    /**
     * 更新部门级别
     * @return void
     */
   public static function updateDepartmentLevel()
   {
       $table = self::query()->get(['id', 'parent_id','dep_id','type_id','level_id'])->toArray();
       foreach ($table as $v){
           $row = self::query()->where('dep_id',$v['parent_id'])->first(['type_id','level_id']);
           $update = [];
           if (empty($row)){
               $update['level_id'] = 1;
           }else{
               $update['level_id'] = $v['type_id'] == $row['type_id'] ? $row['level_id']+1 : 1;
           }
           self::query()->where('dep_id',$v['dep_id'])->update($update);
       }
       return true;
   }

}
