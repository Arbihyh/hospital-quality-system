<?php


namespace App\Services;


use App\Model\User;
use App\Model\UserGroup;
use App\Model\UserLog;
use App\Model\UserMenu;
use App\Model\UserMenuList;
use App\Model\UserSearchLog;

class UserService
{
    /** 是否有权限
     * @param $userGroupId
     * @param $path
     * @return bool
     */
    public static function therePermission($userGroupId, $path)
    {
        // 查询用户组
        $userGroupData = UserGroup::findRole($userGroupId);
        if (!$userGroupData) {
            return false;
        }
        if ($userGroupData['role'] == "all") {
            return true;
        }
        if ($path == "api/user/info" || $path == "api/user/menus") {
            return true;
        }
        // 判断用户组是否有权限
        $pathData = UserMenu::findWhereUrl($path);

        if (!$pathData) {
            return false;
        }
        $roleArr = json_decode($userGroupData['role'], true);
        if (!in_array($pathData['id'], $roleArr) && $pathData['menu_id'] != 12) {
            return false;
        }
        return true;
    }

    /** 获取前台用户列表
     * @param $group_id
     * @param $name
     * @param $page
     * @param $length
     * @return array
     */
    public static function userList($group_id, $name, $page, $length)
    {
        $where = [];
        if (!empty($name)) {
            $where["name"] = $name;
        }
        if (!empty($group_id)) {
            $where["group_id"] = $group_id;
        }
        $count = User::getPageCount($where);
        if ($count > 0) {
            $data = User::getPageAll($where, $page, $length);
            if (!$data) {
                return ["list" => [], "count" => 0];
            } else {
                $ids = array_column($data, 'group_id');
                $userGroup = UserGroup::getInIdAll($ids);
                $userGroup = array_column($userGroup, null, 'id');
                foreach ($data as $k => &$v) {
                    $v["group_name"] = $userGroup[$v["group_id"]]["name"];
                    $v["status"] = $v['id'] == 1 ? 0 : 1;
                    unset($v["password"]);
                    unset($v["salt"]);
                    unset($v["token"]);
                }
                return ["list" => $data, "count" => $count];
            }
        } else {
            return ["list" => [], "count" => 0];
        }
    }


    // 添加前台用户
    public static function addUser($name, $pwd, $groupId, $phone, $realname)
    {
        return User::add($name, $pwd, $groupId, $phone, $realname);
    }

    // 修改前台用户
    public static function editUser($id, $name, $pwd, $groupId, $phone, $realname)
    {
        $data = [];
        if (!empty($name)) {
            $data['name'] = $name;
        }
        if (!empty($pwd)) {
            $data['password'] = $pwd;
        }
        if (!empty($groupId)) {
            $data['group_id'] = $groupId;
        }
        if (!empty($phone)) {
            $data['phone'] = $phone;
        }
        if (!empty($realname)) {
            $data['realname'] = $realname;
        }
        return User::edit(["id" => $id], $data);
    }

    // 查看用户组
    public static function userGroup()
    {
        return UserGroup::getAll(['id','name']);
    }

    // 写入后台用户操作记录
    public static function writeUserLog(array $data)
    {
        $mustDataKey = ['userId', 'name', 'path', 'method', 'queryParams', 'ip', 'title', 'userAgent'];
        $notCheck = ['queryParams'];
        $filter = array_filter(array_keys($data), function ($var) use ($mustDataKey, $notCheck, $data){
            return ( in_array($var, $mustDataKey) && isset($data[$var]) && !empty($data[$var]) ) || in_array($var, $notCheck);
        });
        if (count($filter) == count($mustDataKey)) {
            $content = '';
            if(!empty($data['queryParams'])){
                $params = $data['queryParams'];
                $replaceKeys = ['token', 'pwd', 'password'];
                foreach ($params as $key => &$value) {
                    if(in_array($key, $replaceKeys)){
                        $value = str_repeat('*', strlen($value) );
                    }
                }
                $content = json_encode($params);
            }
            $log = new UserLog();
            $log->path = $data['path'];
            $log->method = $data['method'];
            $log->title = $data['title'];
            $log->content = $content;
            $log->username = $data['name'];
            $log->user_id = $data['userId'];
            $log->user_agent = $data['userAgent'];
            $log->ip = $data['ip'];
            return $log->save();
        }
        return false;
    }

    public static function writeSearchUserLog($data)
    {
        if(!empty($data['queryParams'])){
            $params = $data['queryParams'];
            $content = json_encode($params);

            $contentList = [
                '{"limit":10,"page":1,"keyword":null}',
                '{"page_size":10,"page":1}',
            ];
            if (!in_array($content,$contentList)) {
                $insertData = [
                    'path' =>  $data['path'],
                    'method' => $data['method'],
                    'title' => $data['title'],
                    'type' => $data['type'],
                    'content' => $content,
                    'user_id' => $data['userId'],
                    'username' => $data['name'],
                    'user_agent' => $data['userAgent'],
                    'ip' => $data['ip'],
                    'is_code' => $data['is_code'],
                    'created_at' => date('Y-m-d H:i:s', time()),
                    'updated_at' => date('Y-m-d H:i:s', time())
                ];
                return UserSearchLog::query()->insert($insertData);
            }
        }

        return false;
    }
}
